<?php include("header.php"); 
if(isset($_SESSION['uemail']) && $_SESSION['utype'] == "Seller")
{
$uemail=$_SESSION['uemail'];
$uid=$_SESSION['uid'];
}
else{
	echo "<script>window.open('user_login.php','_self')</script>";
}
?>
<main>
        <div class="breadcrumb-area bg-img" data-bg="assets/img/banner/breadcrumb-banner.webp">
            <div class="container">
                <div class="row">
                    <div class="col-12">
                        <div class="breadcrumb-wrap text-center">
                            <nav aria-label="breadcrumb">
                                <h1 class="breadcrumb-title">My Chat</h1>
                               
                            </nav>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="my-account-wrapper section-padding">
            <div class="container custom-container">
                <div class="row">
                    <div class="col-lg-12">
                        <div class="myaccount-page-wrapper">
                            <div class="row">
                                <div class="col-lg-3 col-md-4">
                                    <div class="myaccount-tab-menu nav" role="tablist">
                                        <a href="seller_dashboard.php" class="" id="download_btn"  role="tab" aria-controls="download" aria-selected="false">
                                            <i class="fa fa-dashboard"></i>
                                            Dashboard
                                        </a>

                                         <a href="upload_for_sale.php" id="download_btn"  role="tab" aria-controls="download" aria-selected="false">
                                            <i class="fa fa-cloud-download"></i>
                                            Upload for Sale
                                        </a>
                                         <a href="upload_for_bidding.php" id="download_btn"  role="tab" aria-controls="download" aria-selected="false">
                                            <i class="fa fa-cloud-download"></i>
                                            Upload for Bidding
                                        </a>

                                        <a href="seller_myorder.php" id="download_btn"  role="tab" aria-controls="download" aria-selected="false">
                                         <i class="fa fa-cart-arrow-down"></i>
                                           Orders
                                        </a>
                                        <a href="seller_mybidding.php" id="download_btn"  role="tab" aria-controls="download" aria-selected="false">
                                         <i class="fas fa-gavel"></i>
                                        &nbsp;   Bidding
                                        </a>
                                        <a href="my_chat2.php" class="active" id="download_btn"  role="tab" aria-controls="download" aria-selected="false">
                                            <i class="far fa-comment"></i>
                                         &nbsp;  Chat
                                        </a>
                                        <a href="user_logout.php"><i class="fa fa-sign-out"></i> Logout</a>
                                    </div>
                                </div>
        
                                <div class="col-lg-9 col-md-8">
                                    <div class="tab-content" id="myaccountContent">
                                     <table border="1" style="width:100%">
                                         <tr style="text-align: center;border:1px solid black">
                                             <th style="border:1px solid black">Sender Name</th>
                                             <th style="border:1px solid black">Last Message</th>
                                             <th style="border:1px solid black">Chat Now</th>
                                             
                                         </tr>
                                        <?php 
                    $fg_order="SELECT msg.sender_id,us.u_name FROM `tbl_chat_message` msg,tbl_user us WHERE msg.sender_id=us.u_id AND msg.receiver_id='$uid' group by msg.sender_id  ";
                    $run_order=mysqli_query($con,$fg_order);
                    while($row_order=mysqli_fetch_array($run_order))
                    {
                      $sender_id=$row_order['sender_id'];
                    $user_name=$row_order['u_name'];
                    $totalview="SELECT msg_text FROM `tbl_chat_message` where sender_id='$sender_id' AND receiver_id='$uid' order by msg_id desc limit 1";
                    $run_totalview=mysqli_query($con,$totalview);
                    $row_totalview=mysqli_fetch_array($run_totalview);
                    $msg_text=$row_totalview['msg_text'];

                        echo "
                    <tr style='border:1px solid black'>";?>
                    <td style="border:1px solid black">
                    <h6 style="text-align: center"><a href="#" style="color:black;text-align: center"><?php echo $user_name ?></a></h6>

                    </td>
                    <td style="border:1px solid black">
                    <h6 style="text-align: center"><a href="#" style="color:black;text-align: center"><?php echo $msg_text ?></a></h6>

                    </td>
                    <td>
                    <div >
                    <center>
                    <a href="message_chat.php?sendid=<?php echo $uid ?>&recid=<?php echo $sender_id ?>" target="_blank" class="action-btn btn-eye"><i class="fas fa-comment-dots"></i></a>
                    </center>
                    </div>
                    </td>
                    </tr>
                    <?php echo"
                            ";
                            }                    
                            ?> 
                                    </table>   
                                    </div>
                                </div> 
                            </div>
                        </div> 
                    </div>
                </div>
            </div>
        </div>
    </main>
<?php include("footer.php"); ?>
<?php 
if(isset($_GET['dbid']))
{
    $dbid=$_GET['dbid'];
    $del_bid="delete from tbl_bidding where bid_id='$dbid'";
    $run_bid=mysqli_query($con,$del_bid);

    if($run_bid)
    {
        echo "<script>alert('Bid Successfully Deleted')</script>";
        echo "<script>window.open('my_bids.php','_self')</script>"; 
    }
    else{
        echo "<script>alert('Bid Not Successfully Deleted')</script>";
        echo "<script>window.open('my_bids.php','_self')</script>";
    }
}
?>