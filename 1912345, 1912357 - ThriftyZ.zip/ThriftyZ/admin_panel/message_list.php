<?php include("header.php");?>
  <div class="content-wrapper">
    <section class="content-header">
      <h1>
        Messages 
      </h1>
      <ol class="breadcrumb">
        <li class="breadcrumb-item"><a href="#"><i class="fa fa-dashboard"></i> Home</a></li>
        <li class="breadcrumb-item"><a href="#">Contact Us</a></li>
        <li class="breadcrumb-item active">Messages Recieved</li>
      </ol>
    </section>
    <section class="content">
      <div class="row">
        <div class="col-12">
          <div class="box box-solid bg-dark">
          <div class="box-header with-border">
          </div>
          <div class="box-body">
				<div class="table-responsive">
				  <table border="1" style="width:100%">
					<thead>
						<tr style="background-color:skyblue;color:black;">
							<th><center>Id</center></th>
              <th><center>Name</center></th>
              <th><center>Email</center></th>
              <th><center>Phone</center></th>
              <th><center>Message</center></th>
              <th>Action</th>
						</tr>
					</thead>
					<tbody>

<?php 

$feth_user="select * from tbl_contactus order by msg_id desc ";
$run_us=mysqli_query($con,$feth_user);
$index=1;
while($rows=mysqli_fetch_array($run_us))
{
$msg_id=$rows['msg_id'];
$user_name=$rows['user_name'];
$user_email=$rows['user_email'];
$user_phone=$rows['user_phone'];
$user_message=$rows['user_message'];

echo "
  <tr style='padding:5px'>
	<td><center style='color:black;padding:5px'>$index</center></td>
  <td><center style='color:black;padding:5px'>$user_name</center></td>
  <td><center style='color:black;padding:5px'>$user_email</center></td>
  <td><center style='color:black;padding:5px'>$user_phone</center></td>
  <td><center style='color:black;padding:5px'>$user_message</center></td>
  <td><a href='?iids=$msg_id' style='color:black;padding:5px' class='text-danger'>Delete</a></td>
	</tr>
";
$index =$index + 1;
}
?>
        </tbody>				  
				</table>
				</div>              
        </div>
        </div>
        </div>
      </div>
    </section>
  </div>

  <?php include("footer.php");?>
  <?php

if(isset($_GET['iids']))
{
	$catid=$_GET['iids'];

	$del_cat="delete from tbl_contactus where msg_id='$catid'";
	$run_del=mysqli_query($con,$del_cat);
if($run_del)
{
	echo "<script>alert('Message  Successfully Deleted')</script>";
	echo "<script>window.open('message_list.php','_self')</script>";
}

else {
	echo "<script>alert('Message Not Successfully Deleted')</script>";
	echo "<script>window.open('message_list.php','_self')</script>";
}
}
?>