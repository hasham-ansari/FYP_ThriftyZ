<?php include("header.php");?>

<div class="breadcrumbs-area position-relative">
        <div class="container">
            <div class="row">
                <div class="col-12 text-center">
                    <div class="breadcrumb-content position-relative section-content">
                        <h3 class="title-3">My Cart</h3>
                        <br>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <div class="cart-main-wrapper mt-no-text">
        <div class="container custom-area">
            <div class="row">
                <div class="col-lg-12 col-custom">
                    <div class="cart-table table-responsive">
                        <table class="table table-bordered">
                            <thead>
                                <tr>
                                    <th class="pro-thumbnail">Image</th>
                                    <th class="pro-title">Product</th>
                                    <th class="pro-price">Price</th>
                                    <th class="pro-quantity">Quantity</th>
                                    <th class="pro-subtotal">Total</th>
                                    <th class="pro-remove">Remove</th>
                                </tr>
                            </thead>
                            <tbody>
                            <?php
                                $total=0;
                                $dc=0;
                                foreach ($_SESSION['mycart'] as $i => $value) {

                                $fet_pro="select * from tbl_upload_for_sale where post_id='$i'";
                                $run_pro=mysqli_query($con,$fet_pro);
                                $row_pro=mysqli_fetch_array($run_pro);
                                $p_title=$row_pro['p_title'];
                                $p_image1=$row_pro['p_image1'];

                                $total=$total + ($value['p'] * $value['q']);
                                $dc=$dc + $value['q'];
                                ?>
                                  <tr>
                                    <td class="pro-thumbnail"><a href="#"><img class="img-fluid" src="upload_image/<?php echo $p_image1 ?>" alt="Product" /></a></td>
                                    <td class="pro-title"><a href="#"><?php echo $p_title ?></a></td>
                                    <td class="pro-price"><span>Rs <?php echo $value['p']  ?></span></td>
                                    <td class="pro-quantity">
                                        <div class="quantity">
                                            <div class="cart-plus-minus">
                                                <input class="cart-plus-minus-box" value="<?php echo $value['q'] ?>" type="text" style="display:inline-block;width:60%">
                                                
                                                <div class="dec qtybutton"  style="display:inline-block;"><a href="mincart.php?pid=<?php echo $i ?>"><i class="fa fa-minus"></i></a></div>
                                                <div class="inc qtybutton"  style="display:inline-block;"><a href="addcart.php?pid=<?php echo $i ?>"><i class="fa fa-plus"></i></a></div>
                                            </div>
                                        </div>
                                    </td>
                                    <td class="pro-subtotal"><span>Rs <?php echo  $value['p'] * $value['q']  ?></span></td>
                                    <td class="pro-remove"><a href="remove.php?pid=<?php echo $i ?>"><i class="fa fa-trash" aria-hidden="true"></i></a></td>
                                </tr>
                            <?php } ?>    
                              
                           
                            </tbody>
                        </table>
                    </div>
                    <div class="cart-update-option d-block d-md-flex justify-content-between">
                        <div class="apply-coupon-wrapper">
                            
                        </div>
                        <div class="cart-update mt-sm-16">
                            <a href="checkout.php?oamount=<?php echo $total ?>" class="btn flosun-button primary-btn rounded-0 black-btn">Proceed Cart</a>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <?php include("footer.php");?>