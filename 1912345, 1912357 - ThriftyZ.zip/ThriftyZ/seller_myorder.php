<?php include("header.php"); 
if(isset($_SESSION['uemail']) && $_SESSION['utype'] == "Seller")
{
$uemail=$_SESSION['uemail'];
$uid=$_SESSION['uid'];
}
else{
	echo "<script>window.open('user_login.php','_self')</script>";
}
?>
<main>
        <div class="breadcrumb-area bg-img" data-bg="assets/img/banner/breadcrumb-banner.webp">
            <div class="container">
                <div class="row">
                    <div class="col-12">
                        <div class="breadcrumb-wrap text-center">
                            <nav aria-label="breadcrumb">
                                <h1 class="breadcrumb-title">My Account</h1>
                            </nav>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="my-account-wrapper section-padding">
            <div class="container custom-container">
                <div class="row">
                    <div class="col-lg-12">
                        <div class="myaccount-page-wrapper">
                            <div class="row">
                                <div class="col-lg-3 col-md-4">
                                    <div class="myaccount-tab-menu nav" role="tablist">
                                        <a href="seller_dashboard.php" class="" id="download_btn"  role="tab" aria-controls="download" aria-selected="false">
                                            <i class="fa fa-dashboard"></i>
                                            Dashboard
                                        </a>

                                        <a href="upload_for_sale.php" id="download_btn"  role="tab" aria-controls="download" aria-selected="false">
                                            <i class="fa fa-cloud-download"></i>
                                            Upload for Sale
                                        </a>
                                        
                                         <a href="upload_for_bidding.php" id="download_btn"  role="tab" aria-controls="download" aria-selected="false">
                                            <i class="fa fa-cloud-download"></i>
                                            Upload for Bidding
                                        </a>

                                        <a href="seller_myorder.php" class="active" id="download_btn"  role="tab" aria-controls="download" aria-selected="false">
                                         <i class="fa fa-cart-arrow-down"></i>
                                           Orders
                                        </a>

                                        <a href="seller_mybidding.php" id="download_btn"  role="tab" aria-controls="download" aria-selected="false">
                                         <i class="fas fa-gavel"></i>
                                        &nbsp;   Bidding
                                        </a>

                                        <a href="my_chat2.php" id="download_btn"  role="tab" aria-controls="download" aria-selected="false">
                                            <i class="far fa-comment"></i>
                                         &nbsp;  Chat
                                        </a>
                                           
                                        <a href="user_logout.php"><i class="fa fa-sign-out"></i> Logout</a>
                                    </div>
                                </div>
                                <div class="col-lg-9 col-md-8">
                                    <div class="tab-content" id="myaccountContent">
                                       <table border="1" style="width:100%">
                                         <tr style="text-align: center;border:1px solid black">
                                             <th style="border:1px solid black">Id</th>
                                             <th style="border:1px solid black">Date</th>
                                             <th style="border:1px solid black">Product</th>
                                             <th style="border:1px solid black">Qty</th>
                                             <th style="border:1px solid black">Amount</th>
                                             <th style="border:1px solid black">Name</th>
                                             <th style="border:1px solid black">Address</th>
                                             <th style="border:1px solid black">Phone</th>
                                             <th style="border:1px solid black">Status</th>
                                         </tr>
                                        <?php 
                    $fg_order="SELECT *,det.order_status as ordstatus FROM `tbl_order_detail` det,tbl_upload_for_sale upd,tbl_orders ord where det.product_id=upd.post_id AND det.order_id=ord.order_id and upd.user_id='$uid'";
                    $run_order=mysqli_query($con,$fg_order);
                    while($row_order=mysqli_fetch_array($run_order))
                    {
                        $selling_price=$row_order['selling_price'];
                        $order_qty=$row_order['order_qty'];
                        $p_title=$row_order['p_title'];
                        $detail_id=$row_order['detail_id'];
                        $user_id=$row_order['user_id'];
                        $user_phone=$row_order['user_phone'];
                        $user_address=$row_order['user_address'];
                        $bill_date=$row_order['bill_date'];
                        $order_status=$row_order['ordstatus'];
                        $order_id=$row_order['order_id'];

                        $am=$selling_price * $order_qty;

                        echo "
                            <tr style='border:1px solid black'>
                            <td style='border:1px solid black'><center>$order_id</center></td>
                            <td style='border:1px solid black'><center>$bill_date</center></td>
                            <td style='border:1px solid black'><span>$p_title</span></td>
                            <td style='border:1px solid black'><center>$order_qty</center></td>
                            <td style='border:1px solid black'><center>$am</center></td>
                            <td style='border:1px solid black'><center>$user_id</center></td>
                            <td style='border:1px solid black'><span>$user_address</span></td>
                            <td style='border:1px solid black'><center>$user_phone</center></td>
                        ";
                        if($order_status == "Pending")
                        {
                            echo "<td style='border:1px solid black'><center><a href='?oid=$detail_id'>Complete Now</a></center></td>";
                        }
                        else{
                          echo" <td style='border:1px solid black'><center>$order_status</center></td>"; 
                        }


                        echo "</tr>

                            ";
                        }                    
                        ?> 
                                    </table>                                 
                                    </div>
                                </div> 
                            </div>
                        </div> 
                    </div>
                </div>
            </div>
        </div>
    </main>
<?php include("footer.php"); ?>
<?php
if(isset($_GET['oid']))
{
    $oid=$_GET['oid'];
    $upd="update tbl_order_detail set order_status='Complete' where detail_id='$oid'";
    $run_upd=mysqli_query($con,$upd);

    if($run_upd)
    {
echo "<script>window.open('seller_myorder.php','_self')</script>";
    }
    else{
        echo "<script>alert('Order Will Not Procedd')</script>";
    }
}
?>