<?php include("header.php"); ?>

    <main>
        <div class="breadcrumb-area bg-img" data-bg="assets/img/banner/breadcrumb-banner.webp">
            <div class="container">
                <div class="row">
                    <div class="col-12">
                        <div class="breadcrumb-wrap text-center">
                            <nav aria-label="breadcrumb">
                                <h1 class="breadcrumb-title">Contact Us</h1>
                                
                            </nav>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <div class="login-register-wrapper section-padding">
            <div class="container">
                <div class="member-area-from-wrap">
                    <div class="row">
                        <div class="col-lg-3"></div>
                        <div class="col-lg-6">
                            <div class="login-reg-form-wrap signup-form">
                                <form  method="post">
                                 <div class="single-input-item" >
                                        <input type="text" placeholder="Enter your Name" name="uname" required />
                                    </div>
                                    <div class="single-input-item" >
                                        <input type="email" placeholder="Enter your Email" name="uemail" required />
                                    </div>
                                     <div class="single-input-item" >
                                        <input type="text" placeholder="Enter your Phone" name="uphone" required />
                                    </div>

                                    <div class="single-input-item" >
                                        <textarea rows="10" class="form-control" name="umessage" placeholder="Enter your message"></textarea>
                                    </div>
                                
                                    <br>
                                    
                                    <div class="single-input-item">
                                        <button class="btn" name="btn_register" type="submit">Send Now</button>
                                    </div>
                                </form>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </main>
<?php include("footer.php"); ?>

<?php 
if(isset($_POST['btn_register']))
{

$uemail=$_POST['uemail'];
$uname=$_POST['uname'];
$uphone=$_POST['uphone'];
$umessage=$_POST['umessage'];
$ins="INSERT INTO `tbl_contactus`(user_name,user_email,user_phone,user_message,msg_date) VALUES ('$uname','$uemail','$uphone','$umessage',NOW())";
$run_ins=mysqli_query($con,$ins);

if($run_ins)
{
    echo "<script>alert('Message Send Successfully')</script>";
    echo "<script>window.open('contact_us.php','_self')</script>";
}
else{
    echo "<script>alert('Message Send Not Successfully')</script>";
    echo "<script>window.open('contact_us.php','_self')</script>";
}
}
?>