<?php include("header.php");
if(isset($_SESSION['uemail']))
{
$pid=$_GET['pid'];
$bstart=$_GET['bstart'];
$uid=$_SESSION['uid'];
$fg_check="SELECT * FROM `tbl_bidding` where user_id='$uid' AND post_id='$pid'";
$run_check=mysqli_query($con,$fg_check);
$row_check=mysqli_num_rows($run_check);
}
else{
    echo "<script>alert('Please Login First to view this page')</script>";
    echo "<script>window.open('user_login.php','_self')</script>";
}
?>

    <main>
        <div class="breadcrumb-area bg-img" data-bg="assets/img/banner/breadcrumb-banner.webp">
            <div class="container">
                <div class="row">
                    <div class="col-12">
                        <div class="breadcrumb-wrap text-center">
                            <nav aria-label="breadcrumb">
                                <h1 class="breadcrumb-title">Bid Now</h1>
                            </nav>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="login-register-wrapper section-padding">
            <div class="container">
                <div class="member-area-from-wrap">
                    <div class="row">
                        <div class="col-lg-5">
                            <div class="login-reg-form-wrap signup-form">
                                <h2>Bid Now !</h2>
                                <p><b>Bid Start : <?php echo number_format($bstart) ?> </b></p>
                                <form  method="post">
                                 <div class="single-input-item" >
                                        <input type="number" placeholder="Enter your Amount" name="uoffer" required />
                                    </div>
                                    <div class="single-input-item" >
                                        <textarea rows="5" class="form-control" name="umessage" placeholder="Enter your Offer"></textarea>
                                    </div>                                    
                                    <br>
                                    <div class="single-input-item">
                                        <?php if($row_check == 0){ ?>
                                        <button class="btn" name="btn_register" type="submit">Bid Now</button>
                                        <?php } else { ?>
                                        <button class="btn" >Already Bid</button>
                                        <?php } ?>
                                    </div>
                                </form>
                            </div>
                        </div>
                        
                        <div class="col-sm-7">
                        <?php 
                            $bd_detail="SELECT * FROM `tbl_bidding` bid,tbl_user us where bid.user_id=us.u_id AND bid.post_id='$pid'";
                            $run_detail=mysqli_query($con,$bd_detail);
                            $cn_detail=mysqli_num_rows($run_detail);
                        ?>
                        <h4>Product Bid's<a class="btn btn-warning" >Total Bids : <?php echo $cn_detail ?></a></h4>
                            <br>

                            <table border="1" style="width: 100%">
                                <tr class="bg-warning">
                                    <th style="border: 1px solid grey;color:white"><center>User Name</center></th>
                                    <th style="border: 1px solid grey;color:white"><center>Bid Amount</center></th>
                                    <th style="border: 1px solid grey;color:white"><span>&nbsp;&nbsp;&nbsp;Bid Detail</span></th>
                                </tr>
                                 <?php 
            while($row_detail=mysqli_fetch_array($run_detail))
            {
                $u_name=$row_detail['u_name'];
                $bid_amount=$row_detail['bid_amount'];
                $bid_detail=$row_detail['bid_detail'];

                echo "
                <tr>
                    <td style='color:black;border:1px solid grey'><center>$u_name</center></td>
                    <td style='color:black;border:1px solid grey'><center>".number_format($bid_amount)."</center></td>
                    <td style='color:black;border:1px solid grey'><span>&nbsp;&nbsp;$bid_detail</span></td>
                </tr>
                ";
            }
            ?>
            </table>
                </div>
                </div>
                </div>
            </div>
        </div>
    </main>
<?php include("footer.php"); ?>
<?php 
if(isset($_POST['btn_register']))
{

$uoffer=$_POST['uoffer'];
$umessage=$_POST['umessage'];
$ins="INSERT INTO `tbl_bidding`(user_id,post_id,bid_amount,bid_detail,post_date) VALUES ('$uid','$pid','$uoffer','$umessage',NOW())";
$run_ins=mysqli_query($con,$ins);

if($run_ins)
{
    echo "<script>alert('Bid Send Successfully')</script>";
    echo "<script>window.open('bid_now.php?pid=$pid&bstart=$bstart','_self')</script>";
}
else{
    echo "<script>alert('Bid Send Not Successfully')</script>";
    echo "<script>window.open('bid_now.php?pid=$pid&bstart=$bstart','_self')</script>";
}     
}
?>