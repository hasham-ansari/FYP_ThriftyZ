<?php include("header.php");

if(!isset($_SESSION['uemail']))
{
echo "<script>window.open('user_login.php','_self')</script>";
}
$qid=$_GET['qid'];

$fg_detail="SELECT question_title,question_detail FROM `tbl_forum_question` where question_id='$qid'";
$run_detail=mysqli_query($con,$fg_detail);
$row_detail=mysqli_fetch_array($run_detail);
$question_title=$row_detail['question_title'];
$question_detail=$row_detail['question_detail'];
?>
<main>
<div class="breadcrumbs-area position-relative">
        <div class="container">
            <div class="row">
                <div class="col-6 col-sm-6 ">
                    <div class="breadcrumb-content  section-content">
                        <h3 class="title-3"><b>Title : </b><?php echo $question_title ?></h3>
                        <p><b>Detail : </b><?php echo $question_detail ?></p>
                        <br>
                    </div>
                </div>

                <div class="col-6 col-sm-6 text-right">
                    <div class="breadcrumb-content  section-content" style="text-align: right">
                        <a href="add_forum_answer.php?qid=<?php echo $qid ?>" class="btn btn-warning" >+Add Answer</a>
                        <br>
                    </div>
                </div>
            </div>
        </div>
    </div>
     <div class="shop-main-wrapper section-padding">
            <div class="container">
                <div class="row">
                    <div class="col-12">
                        <div class="shop-product-wrapper">
                            <div class="shop-product-wrap list-view row mbn-50">
                            <?php 
                            $fg_shoe="SELECT * FROM `tbl_forum_answer` where question_id='$qid'";
                            
                            $run_shoe=mysqli_query($con,$fg_shoe);
                            $cn_shoe=mysqli_num_rows($run_shoe);
                            
                            while($row_shoe=mysqli_fetch_array($run_shoe))
                            {
                                $question_id=$row_shoe['question_id'];
                                $user_name=$row_shoe['user_name'];
                                $user_email=$row_shoe['user_email'];
                                $question_detail=$row_shoe['question_detail'];
                                $user_date=$row_shoe['user_date'];
                            ?>
                                <div class="col-xl-3 col-lg-4 col-sm-6">
                                    <div class="product-list-item mb-30">
                                        
                                        <div class="product-content-list">
                                            
                                            <p style="color:black"> - <?php echo $question_detail ?></p>
                                            <p style="margin-top: -10px"><b>Post By : </b><?php echo $user_name ?> On <b><?php echo $user_date ?></b></p>
                                        </div>
                                    </div>
                                </div>
                            <?php  } ?>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </main>
<?php include("footer.php");?>