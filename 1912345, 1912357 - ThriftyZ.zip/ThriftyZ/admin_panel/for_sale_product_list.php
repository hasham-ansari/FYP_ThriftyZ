<?php
include("header.php");
?>

<div class="content-wrapper">
    <section class="content-header">
      <h1>
        Sale Product
      </h1>
      <ol class="breadcrumb">
        <li class="breadcrumb-item"><a href="#"><i class="fa fa-dashboard"></i> Home</a></li>
        <li class="breadcrumb-item"><a href="#">Uploaded Products</a></li>
        <li class="breadcrumb-item active">Sale Products</li>
      </ol>
    </section>
    <section class="content">
      <div class="row">
        <div class="col-12">
          <div class="box box-solid bg-dark">
          <div class="box-body">
				<div class="table-responsive">
				  <table border="1" style="width:100%">
					<thead>
						<tr style="background-color:skyblue;color:black;">
							<th><center>Id</center></th>
              <th><center>Image</center></th>
              <th><center>User</center></th>
              <th><center>Product</center></th>
              <th><center>Price</center></th>
            </tr>
					</thead>
					<tbody>
<?php 

$feth_user="SELECT * FROM `tbl_upload_for_sale` bid,tbl_user us where bid.user_id=us.u_id";
$run_us=mysqli_query($con,$feth_user);
$index=1;
while($rows=mysqli_fetch_array($run_us))
{
$post_id=$rows['post_id'];
$p_title=$rows['p_title'];
$p_price=$rows['p_price'];
$p_image1=$rows['p_image1'];
$u_name=$rows['u_name'];

echo "
  <tr style='padding:5px'>
	<td><center style='color:black;padding:5px'>$post_id</center></td>
  <td><center style='color:black;padding:5px'><img src='../upload_image/$p_image1' style='height:100px;width:100px'></center></td>
  <td><center style='color:black;padding:5px'>$u_name</center></td>
  <td><center style='color:black;padding:5px'>$p_title</center></td>
  <td><center style='color:black;padding:5px'>$p_price</center></td>
  </tr>

";
}
?>
				</tbody>				  
					
				</table>
				</div>              
            </div>
          </div>
          </div>
      </div>
    </section>

  </div>
<?php include("footer.php");?>