<?php
include("header.php");
$pid=$_GET['pid'];

$fet_pro="select * from tbl_upload_for_sale where post_id='$pid'";
$run_pro=mysqli_query($con,$fet_pro);
$row_pro=mysqli_fetch_array($run_pro);
$pprice=$row_pro['p_price'];

if(isset($_SESSION['mycart'][$pid]))
{
	$q=$_SESSION['mycart'][$pid]["q"];
	$q++;
	$_SESSION['mycart'][$pid]=array("p"=>$pprice,"q"=>$q);
}
else {
$_SESSION['mycart'][$pid]=array("p"=>$pprice,"q"=>$qty); 
}
 echo "<script>window.open('mycart.php','_self')</script>";
?>
