<?php include("header.php"); ?>

<main>
        <div class="breadcrumb-area bg-img" data-bg="assets/img/banner/breadcrumb-banner.webp">
            <div class="container">
                <div class="row">
                    <div class="col-12">
                        <div class="breadcrumb-wrap text-center">
                            <nav aria-label="breadcrumb">
                                <h1 class="breadcrumb-title">Login Now</h1>
                            </nav>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="login-register-wrapper section-padding">
            <div class="container">
                <div class="member-area-from-wrap">
                    <div class="row">
                    <div class="col-lg-3"></div>
                        <div class="col-lg-6">
                            <div class="login-reg-form-wrap signup-form">
                                <h2>Sign in</h2>
                                <form  method="post">
                                 
                                    <div class="single-input-item" >
                                        <input type="email" placeholder="Enter your Email" name="uemail" required />
                                    </div>
                                     <div class="single-input-item" >
                                        <input type="password" placeholder="Enter your Password" name="upass" required min="6" max="100"/>
                                    </div>
                                     <div class="single-input-item">
                                       <select class="form-control" name="utype" id="utype" required="">
                                           <option value="" hidden="">Select User Type</option>
                                           <option>Buyer</option>
                                           <option>Seller</option>
                                       </select>
                                   
                                    </div>
                                    <br>
                                    <div class="single-input-item">
                                        <div class="login-reg-form-meta">
                                            <div class="remember-meta">
                                                <div class="custom-control custom-checkbox">
                                                  <p>Don't Have an Account ? <a href="user_register.php">Register Now</a></p> 
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="single-input-item">
                                        <button class="btn" name="btn_register" type="submit">Login</button>
                                    </div>
                                </form>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </main>
<?php include("footer.php"); ?>


<?php 
if(isset($_POST['btn_register']))
{

$uemail=$_POST['uemail'];
$upass=$_POST['upass'];
$utype=$_POST['utype'];

$check="select * from tbl_user where u_email='$uemail' AND u_pass='$upass' AND u_type='$utype'";
$run_check=mysqli_query($con,$check);
$row_check=mysqli_num_rows($run_check);
if($row_check != 0)
{
  $_SESSION['uemail']=$uemail;
  $_SESSION['utype']=$utype;
  $cn_check=mysqli_fetch_array($run_check);
  $_SESSION['uid']=$cn_check['u_id'];
  $_SESSION['uname']=$cn_check['u_name'];
  $verify_status=$cn_check['verify_status'];

  if($verify_status != "Pending"){
  
  if($utype == "Buyer")
  {
   echo "<script>alert('Login Successful')</script>";
    echo "<script>window.open('index.php','_self')</script>";

  }
  else{
    echo "<script>alert('Login Successful')</script>";
    echo "<script>window.open('seller_dashboard.php','_self')</script>";
  }
}
  else
  {
    echo "<script>alert('Email Not Verified')</script>";
    echo "<script>window.open('user_login.php','_self')</script>"; 
  }
}
else{
    echo "<script>alert('Email or Password Does Not Match')</script>";
    echo "<script>window.open('user_login.php','_self')</script>";
}     
}
?>