<?php include("header.php"); ?>
<main>
        <div class="breadcrumb-area bg-img" data-bg="assets/img/banner/breadcrumb-banner.webp">
            <div class="container">
                <div class="row">
                    <div class="col-12">
                        <div class="breadcrumb-wrap text-center">
                            <nav aria-label="breadcrumb">
                                <h1 class="breadcrumb-title">Add New Forum Question</h1>
                                
                            </nav>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="login-register-wrapper section-padding">
            <div class="container">
                <div class="member-area-from-wrap">
                    <div class="row">
                     
                    <div class="col-lg-3"></div>
                        <div class="col-lg-6">
                            <div class="login-reg-form-wrap signup-form">
                                
                                <form  method="post">
                                 
                                    <div class="single-input-item" >
                                        <input type="text" placeholder="Enter your Question Title" name="utitle" required />
                                    </div>
                                     <div class="single-input-item" >
                                        <textarea type="text" rows="5" placeholder="Enter your Question Detail" name="udetail" required></textarea> 
                                    </div>                                   
                                    <br>
                                    
                                    <div class="single-input-item">
                                        <button class="btn" name="btn_register" type="submit">Add Now</button>
                                    </div>
                                </form>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </main>
<?php include("footer.php"); ?>

<?php 
if(isset($_POST['btn_register']))
{

$utitle=$_POST['utitle'];
$udetail=$_POST['udetail'];
$uemail=$_SESSION['uemail'];
$uname=$_SESSION['uname'];
$ins_forum="INSERT INTO tbl_forum_question(user_email,user_name,question_title,question_detail,question_date) VALUES ('$uemail','$uname','$utitle','$udetail',NOW())";
$run_forum=mysqli_query($con,$ins_forum);

if($run_forum)
{
    echo "<script>alert('Add Successfully')</script>";
    echo "<script>window.open('forum.php','_self')</script>";
}
else{
    echo "<script>alert('Add Not Successfully')</script>";
    echo "<script>window.open('forum.php','_self')</script>";
}   
}
?>