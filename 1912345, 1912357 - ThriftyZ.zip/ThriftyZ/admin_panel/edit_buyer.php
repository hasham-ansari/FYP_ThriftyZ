<?php include("header.php");
$uid=$_GET['uid'];
$fg_us="SELECT u_name,u_pass,u_phone,u_address FROM `tbl_user` where u_id='$uid'";
$run_us=mysqli_query($con,$fg_us);
$row_us=mysqli_fetch_array($run_us);
$u_name=$row_us['u_name'];
$u_pass=$row_us['u_pass'];
$u_phone=$row_us['u_phone'];
$u_address=$row_us['u_address'];
?>
  <div class="content-wrapper">
    <section class="content-header">
      <h1>Update User Information</h1>
      <ol class="breadcrumb">
        <li class="breadcrumb-item"><a href="#"><i class="fa fa-dashboard"></i> Home</a></li>
        <li class="breadcrumb-item"><a href="#">Registered Users</a></li>
        <li class="breadcrumb-item active">Update User Information</li>
      </ol>
    </section>
    <section class="content">
      <div class="box bg-hexagons-dark">
      <div class="box-body">
      <form method="post">
			<div class="row">
      <div class="col-md-4 col-xl-4">
          <div class="form-group">
                <label>Name</label>
                <input type="text" class="form-control" name="uname" style="height: 30px" required="required" value="<?php echo $u_name ?>">
          </div>
          </div>
            <div class="col-md-4 col-xl-4">
              <div class="form-group">
                <label>Password</label>
                <input type="text" class="form-control" name="upass" style="height: 30px" required="required" value="<?php echo $u_pass ?>">
              </div>
            </div>
               <div class="col-md-4 col-xl-4">
                <div class="form-group">
                  <label>Phone</label>
                  <input type="text" class="form-control" name="uphone" style="height: 30px" required="required" value="<?php echo $u_phone ?>">
                </div>
              </div>
              <div class="col-md-6 col-xl-6">
                <div class="form-group">
                  <label>Address</label>
                  <input type="text" class="form-control" name="uaddress" style="height: 30px" required="required" value="<?php echo $u_address ?>">
                </div>
              </div>
               <div class="col-md-12 col-xl-12">
                <div class="form-group">
              <center>
                  <input type="submit" class="btn btn-info" name="br_sub">
                </center>
                </div>
              </div>			
        </div>
      </form>
      </div>      
    </section>
  </div>
<?php include("footer.php");?>

<?php
if(isset($_POST['br_sub']))
{
  $uname=$_POST['uname'];
  $upass=$_POST['upass'];
  $uphone=$_POST['uphone'];
  $uaddress=$_POST['uaddress'];
  $inh="update `tbl_user` set u_name='$uname',u_pass='$upass',u_phone='$uphone',u_address='$uaddress' where u_id='$uid'";
  $run_cat=mysqli_query($con,$inh);
  if($run_cat)
  {
    echo "<script>alert('User Successfully Updated')</script>";
    echo "<script>window.open('edit_buyer.php?uid=$uid','_self')</script>";
  }

  else {
    echo "<script>alert('User Not Successfully Updated')</script>";
    echo "<script>window.open('edit_buyer.php?uid=$uid','_self')</script>";
  }
}
?>