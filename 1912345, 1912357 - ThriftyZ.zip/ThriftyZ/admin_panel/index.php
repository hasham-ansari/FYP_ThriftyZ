<?php include("header.php");?>

  <div class="content-wrapper">
    <section class="content-header">
      <h1>
        Dashboard
        <small>Control panel</small>
      </h1>
      <ol class="breadcrumb">
        <li class="breadcrumb-item"><a href="#"><i class="fa fa-dashboard"></i> Home</a></li>
        <li class="breadcrumb-item">Dashboard</li>
      </ol>
    </section>

    <section class="content">
      <div class="row">

      </div>
	</section>
  </div>
<?php include("footer.php");?>