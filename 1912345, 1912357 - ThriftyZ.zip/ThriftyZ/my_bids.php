<?php include("header.php"); 
if(isset($_SESSION['uemail']) && $_SESSION['utype'] == "Buyer")
{
$uemail=$_SESSION['uemail'];
$uid=$_SESSION['uid'];
}
else{
	echo "<script>window.open('user_login.php','_self')</script>";
}
?>
    <main>
        <div class="breadcrumb-area bg-img" data-bg="assets/img/banner/breadcrumb-banner.webp">
            <div class="container">
                <div class="row">
                    <div class="col-12">
                        <div class="breadcrumb-wrap text-center">
                            <nav aria-label="breadcrumb">
                                <h1 class="breadcrumb-title">My Bids</h1>
                            </nav>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="my-account-wrapper section-padding">
            <div class="container custom-container">
                <div class="row">
                    <div class="col-lg-12">
                        <div class="myaccount-page-wrapper">
                            <div class="row">
                                <div class="col-lg-3 col-md-4">
                                    <div class="myaccount-tab-menu nav" role="tablist">
                                        <a href="buyer_dashboard.php" role="tab" aria-controls="dashboard" aria-selected="false">
                                            <i class="fa fa-dashboard"></i>
                                            Dashboard
                                        </a>

                                        <a href="mycart.php" id="download_btn"  role="tab" aria-controls="download" aria-selected="false">
                                            <i class="fa fa-cart-plus"></i>
                                            My Cart
                                        </a>

                                         <a href="buyer_myorder.php" id="download_btn"  role="tab" aria-controls="download" aria-selected="false">
                                            <i class="fa fa-cart-plus"></i>
                                           Orders
                                        </a>
                                        <a href="my_bids.php" class="active" id="download_btn"  role="tab" aria-controls="download" aria-selected="false">
                                            <i class="fa fa-cart-plus"></i>
                                           My Bids
                                        </a>
                                        <a href="my_winbids.php" id="download_btn"  role="tab" aria-controls="download" aria-selected="false">
                                            <i class="fa fa-credit-card"></i>
                                           Win Bids
                                        </a>
                                        <a href="my_chat.php" id="download_btn"  role="tab" aria-controls="download" aria-selected="false">
                                            <i class="far fa-comment"></i>
                                           Chat
                                        </a>
                                        <a href="user_logout.php"><i class="fa fa-sign-out"></i> Logout</a>
                                    </div>
                                </div>
                                <div class="col-lg-9 col-md-8">
                                    <div class="tab-content" id="myaccountContent">
                                     <table border="1" style="width:100%">
                                         <tr style="text-align: center;border:1px solid black">
                                             <th style="border:1px solid black">Post Image</th>
                                             <th style="border:1px solid black">Post Title</th>
                                             <th style="border:1px solid black">Your Bid</th>
                                             <th style="border:1px solid black">Action</th>
                                         </tr>
                                        <?php 
                    $fg_order="SELECT * FROM `tbl_bidding` bids,tbl_upload_for_bidding pst where bids.post_id=pst.post_id AND bids.user_id='$uid'";
                    $run_order=mysqli_query($con,$fg_order);
                    while($row_order=mysqli_fetch_array($run_order))
                    {
                        $p_image1=$row_order['p_image1'];
                        $p_title=$row_order['p_title'];
                        $bid_amount=$row_order['bid_amount'];
                        $bid_id=$row_order['bid_id'];

                        echo "
                            <tr style='border:1px solid black'>
                                <td style='border:1px solid black'><center><img src='upload_image/$p_image1' style='width:130px;height:130px'></center></td>
                                <td style='border:1px solid black'><center>$p_title</center></td>
                                <td style='border:1px solid black'><center>Rs $bid_amount</center></td>
                                <td style='border:1px solid black'><center><a href='?dbid=$bid_id' class='btn btn-danger'>Delete</a></center></td>
                            </tr>
                        ";
                    }                    
                    ?> 
                                    </table>   
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </main>
<?php include("footer.php"); ?>
<?php 
if(isset($_GET['dbid']))
{
    $dbid=$_GET['dbid'];

    $del_bid="delete from tbl_bidding where bid_id='$dbid'";
    $run_bid=mysqli_query($con,$del_bid);

    if($run_bid)
    {
        echo "<script>alert('Bid Successfully Deleted')</script>";
        echo "<script>window.open('my_bids.php','_self')</script>"; 
    }
    else{
        echo "<script>alert('Bid Not Successfully Deleted')</script>";
        echo "<script>window.open('my_bids.php','_self')</script>";
    }
}
?>