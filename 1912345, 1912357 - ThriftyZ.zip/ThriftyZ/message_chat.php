<?php include("header.php");
if(!isset($_SESSION['uemail']))
{
  echo "<script>window.open('user_login.php','_self')</script>";
}
$user_email=$_SESSION['uemail'];
$sendid=$_GET['sendid'];
$recid=$_GET['recid'];

$fg_rec="select u_name from tbl_user where u_id='$recid'";
$run_rec=mysqli_query($con,$fg_rec);
$row_rec=mysqli_fetch_array($run_rec);
$user_name=$row_rec['u_name'];
?>

<div class="breadcrumbs-area position-relative">
        <div class="container">
            <div class="row">
                <div class="col-12 text-center">
                    <div class="breadcrumb-content position-relative section-content">
                        <h3 class="title-3">Chat Messenger</h3>
                        <br>
                       
                    </div>
                </div>
            </div>
        </div>
    </div>

<input type="hidden" value="<?php echo $sendid ?>" id="sendid">
<input type="hidden" value="<?php echo $recid ?>" id="recid">
<div class="dashboard-content">
<div class="container">

<div class="profile-content">
<div class="row dashboard-info chat-window">
<div class="col-lg-2"></div>
<div class="col-lg-8">
<div class="chat-cont-right">
<div class="chat-header">

<div class="media d-flex align-items-center">
<div class="media-img-wrap flex-shrink-0">
<div class="avatar ">
<img src="assets/avatar2.png" alt="User Image" class="avatar-img rounded-circle">
</div>
</div>
<div class="media-body flex-grow-1">
<div class="user-name"><?php echo $user_name ?></div>
</div>
</div>
</div>

<div class="row">
  <div class="col-sm-12" style="height: 350px;border: 1px solid gray;margin-right: 80px;margin-top: 20px">
  <ul id="messagedatas">
    
  </ul>
  </div>

</div>
<div class="row">

<div class="col-sm-11">
  <br>
<input type="text" class="input-msg-send form-control" id="txtmsg" placeholder="Type something">

</div>
<div class="col-sm-1">
  <br>
<button type="button" id="btnsend" class="btn msg-send-btn"><i class="fas fa-paper-plane"></i></button>
<br><br>
</div>
</div>
</div>
</div>
</div>
</div>
</div>
</div>
<script src="https://code.jquery.com/jquery-3.7.0.js" integrity="sha256-JlqSTELeR4TLqP0OG9dxM7yDPqX1ox/HfgiSLBj8+kM=" crossorigin="anonymous"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery-ajaxy/1.6.1/scripts/jquery.ajaxy.min.js" integrity="sha512-bztGAvCE/3+a1Oh0gUro7BHukf6v7zpzrAb3ReWAVrt+bVNNphcl2tDTKCBr5zk7iEDmQ2Bv401fX3jeVXGIcA==" crossorigin="anonymous" referrerpolicy="no-referrer"></script>
<script type="text/javascript">
	messagedata();
	$('#btnsend').click(function(){
		
    messagesend();
  
	});
	$('#txtmsg').keypress(function (e) {
 var key = e.which;
 if(key == 13)  // the enter key code
  {
    messagesend();  
  }
});

	function messagesend()
	{
		 var txtmsg=$('#txtmsg').val();
     var sendid=$('#sendid').val();
     var recid=$('#recid').val();

     $.ajax({
      url:"insertmessage.php",
      method:"POST",
      data:{txtmsg:txtmsg,sendid:sendid,recid:recid},
      dataType:"text",
      success:function(data){
      	$('#txtmsg').val("");
      	messagedata();     
      }
      
    });
	}

	function messagedata()
	{
      var sendid=$('#sendid').val();
     var recid=$('#recid').val();
	$.ajax({
      url:"empty_chat.php",
      method:"POST",
      data:{sendid:sendid,recid:recid},
      dataType:"text",
      success:function(data){
      	$('#messagedatas').html(data);     
      }
      
    });

		
	}
</script>
<?php include("footer.php");?>