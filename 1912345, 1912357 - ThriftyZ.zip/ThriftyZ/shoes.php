<?php include("header.php");
if(isset($_GET['bid']))
{
	$bid=$_GET['bid'];
}
$uid=$_SESSION['uid'];
 ?>
  <main>
        <div class="breadcrumb-area bg-img" data-bg="assets/breadcrumb-banner.webp">
            <div class="container">
                <div class="row">
                    <div class="col-12">
                        <div class="breadcrumb-wrap text-center">
                            <nav aria-label="breadcrumb">
                                <h1 class="breadcrumb-title">Shoe's</h1>
                                
                            </nav>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="shop-main-wrapper section-padding">
            <div class="container">
                <div class="row">
                    <div class="col-12">
                        <div class="shop-product-wrapper">
                            <div class="shop-top-bar">
                                <div class="row">
                                    <div class="col-xl-5 col-lg-4 col-md-3 order-2 order-md-1">
                                        <div class="top-bar-left">
                                           <form method="get" action="shoes.php">
                                           	<input type="text" class="form-control" name="ukeyword" style="width:70% !important;display: inline-block;">
                                           	<input type="hidden" name="bid" value="<?php echo $bid ?>">
                                           	<input type="submit" name="Search" class="btn btn-warning" style="width:25% !important;display: inline-block;" value="Search">
                                           </form>
                                        </div>
                                    </div>
                                   
                                </div>
                            </div>
                            <div class="shop-product-wrap list-view row mbn-50">
                                
                            <?php 
                            if(isset($_GET['ukeyword']))
                            {
                            	$ukeyword=$_GET['ukeyword'];
                            	$bid=$_GET['bid'];
                            	$fg_shoe="select * from tbl_upload_for_sale where sold_status='Pending' AND p_brand='$bid' AND (p_title like '%$ukeyword%' OR p_brand like '%$ukeyword%' OR p_detail like '%$ukeyword%')";
                            }
                            else{
                            	$fg_shoe="select * from tbl_upload_for_sale where sold_status='Pending' AND p_brand='$bid'";
                            }
                            
                            $run_shoe=mysqli_query($con,$fg_shoe);
                            $cn_shoe=mysqli_num_rows($run_shoe);
                            if($cn_shoe ==0 )
                            {
                            	echo "<div class='col-xl-12 col-lg-12 col-sm-12'>
                            	<center><br><h3>No Product Found in '$ukeyword' .. !</h3></center>
                            	</div>";
                            }
                            while($row_shoe=mysqli_fetch_array($run_shoe))
                            {
                            	$post_id=$row_shoe['post_id'];
                            	$user_id=$row_shoe['user_id'];
                            	$p_title=$row_shoe['p_title'];
                            	$p_price=$row_shoe['p_price'];
                            	$p_brand=$row_shoe['p_brand'];
                            	$p_image1=$row_shoe['p_image1'];
                            	$p_image2=$row_shoe['p_image2'];
                            	$p_image3=$row_shoe['p_image3'];
                            	$p_detail=$row_shoe['p_detail'];
                            	$p_type=$row_shoe['p_type'];

                                $fg_udetail="select * from tbl_user where u_id='$user_id'";
                                $run_udetail=mysqli_query($con,$fg_udetail);
                                $row_udetail=mysqli_fetch_array($run_udetail);
                                $latitude=$row_udetail['latitude'];
                                $longitude=$row_udetail['longitude'];
                           

                            ?>
                                <div class="col-xl-3 col-lg-4 col-sm-6">
                                    <div class="product-list-item mb-30">
                                        <div class="product-thumb">
                                            <a href="#">
                                                <img src="upload_image/<?php echo $p_image1 ?>" alt="product thumb">
                                            </a>
                                        </div>
                                        <div class="product-content-list">
                                            <h5 class="product-name">
                                                <a href="#"><?php echo $p_title ?></a>
                                            </h5>
                                            <div class="price-box">
                                                <span class="price-regular">Rs <?php echo number_format($p_price) ?></span>
                                            </div>
                                            <p><b>Type : </b><?php echo $p_type ?></p>
                                            <p><?php echo $p_detail ?></p>
                                            <div class="product-link-2 position-static">
                                               
                                                <a href="cart.php?pid=<?php echo $post_id ?>&qty=1" data-bs-toggle="tooltip" title="Add To Cart"><i class="ion-bag"></i></a>
                                                <a href="message_chat.php?sendid=<?php echo $uid ?>&recid=<?php echo $user_id ?>"> <span data-bs-toggle="tooltip"
                                                    title="Chat Now"><i class="fas fa-comments"></i></span> </a>
                                                    <a href="https://www.google.com/maps/?q= <?php echo $latitude ?>,<?php echo $longitude ?>" target="_blank" data-bs-toggle="tooltip" title="Store Navigation"><i class="ion-location"></i></a>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                           <?php  } ?>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </main>

<?php include("footer.php");?>

