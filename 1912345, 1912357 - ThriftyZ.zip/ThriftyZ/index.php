<?php include("header.php");
$uid=$_SESSION['uid'];
?>
    <main>
        <section class="hero-slider">
            <div class="container">
                <div class="row">
                    <div class="col-12">
                        <div class="hero-slider-active slick-arrow-style slick-arrow-style_hero slick-dot-style">
                            <div class="hero-single-slide">
                                <div class="hero-slider-item bg-img" data-bg="assets/img/slider/slider-2.webp">
                                    <div class="hero-slider-content slide-1">
                                        <h5 class="slide-subtitle">Top Selling!</h5>
                                        <h2 class="slide-title">New Collection</h2>
                                        <p class="slide-desc">Top Brand products are waiting for you , explore the shop now!</p>
                                        <a href="shoes.php?bid=6" class="btn btn-hero">SHOP NOW</a>
                                    </div>
                                </div>
                            </div>
                            <div class="hero-single-slide">
                                <div class="hero-slider-item bg-img" data-bg="assets/img/slider/slider-1.webp">
                                    <div class="hero-slider-content slide-1">
                                        <h5 class="slide-subtitle">Best Auction Product!</h5>
                                        <h2 class="slide-title">Best Products</h2>
                                        <p class="slide-desc">Top Brand product is waiting for you , Bid Now in our auction house</p>
                                        <a href="auction.php?bid=3" class="btn btn-hero">BID NOW</a>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </section>
        <section class="our-product section-padding">
            <div class="container">
                <div class="row">
                    <div class="col-12">
                        <div class="section-title text-center">
                            <h2 class="title">Newest Products for Sale</h2>
                            <p class="sub-title">Check out our latest uploaded products first here!</p>
                        </div>
                    </div>
                </div>
                <div class="row">
                    <div class="col-12">
                        <div class="product-carousel-4 mbn-50 slick-row-15 slick-arrow-style">
                            <?php 
                            $fg_sale="select * from tbl_upload_for_sale where sold_status='Pending' order by post_id desc limit 10";
                            $run_sale=mysqli_query($con,$fg_sale);
                            while($row_sale=mysqli_fetch_array($run_sale))
                            {
                                $post_id=$row_sale['post_id'];
                                $user_id=$row_sale['user_id'];
                                $p_title=$row_sale['p_title'];
                                $p_price=$row_sale['p_price'];
                                $p_brand=$row_sale['p_brand'];
                                $p_image1=$row_sale['p_image1'];
                                $p_image2=$row_sale['p_image2'];
                                $p_image3=$row_sale['p_image3'];
                                $p_detail=$row_sale['p_detail'];
                                $p_type=$row_sale['p_type'];
                                $fg_udetail="select * from tbl_user where u_id='$user_id'";
                                $run_udetail=mysqli_query($con,$fg_udetail);
                                $row_udetail=mysqli_fetch_array($run_udetail);
                                $latitude=$row_udetail['latitude'];
                                $longitude=$row_udetail['longitude'];


                            ?>
                            <div class="product-item mb-50">
                                <div class="product-thumb">
                                    <a href="#">
                                        <img src="upload_image/<?php echo $p_image1 ?>" alt="">
                                    </a>
                                </div>
                                <div class="product-content">
                                    <h5 class="product-name">
                                        <a href="#"><?php echo $p_title ?></a>
                                    </h5>
                                    <div class="price-box">
                                        <span class="price-regular">Rs <?php echo number_format($p_price) ?></span>
                                    </div>
                                    <div class="product-action-link">
                                       
                                        <a href="cart.php?pid=<?php echo $post_id ?>&qty=1" data-bs-toggle="tooltip" title="Add To Cart"><i class="ion-bag"></i></a>
                                        <a href="message_chat.php?sendid=<?php echo $uid ?>&recid=<?php echo $user_id ?>" > <span data-bs-toggle="tooltip"
                                            title="Chat Now"><i class="fas fa-comments"></i></span> </a>
                                            <a href="https://www.google.com/maps/?q= <?php echo $latitude ?>,<?php echo $longitude ?>" target="_blank" data-bs-toggle="tooltip" title="Store Navigation"><i class="ion-location"></i></a>
                                    </div>
                                </div>
                            </div>
                        <?php } ?>
                        </div>
                    </div>
                </div>
            </div>
        </section>
          <section class="our-product section-padding">
            <div class="container">
                <div class="row">
                    <div class="col-12">
                        <div class="section-title text-center">
                            <h2 class="title">Newest Products in Auction</h2>
                            <p class="sub-title">Check out the latest uploaded products in our auction house!</p>
                        </div>
                    </div>
                </div>
                <div class="row">
                    <div class="col-12">
                        <div class="product-carousel-4 mbn-50 slick-row-15 slick-arrow-style">
                            <?php 
                            $fg_sale="select * from tbl_upload_for_bidding where sold_status='Pending' order by post_id desc limit 10";
                            $run_sale=mysqli_query($con,$fg_sale);
                            while($row_sale=mysqli_fetch_array($run_sale))
                            {
                                $post_id=$row_sale['post_id'];
                                $user_id=$row_sale['user_id'];
                                $p_title=$row_sale['p_title'];
                                $p_price=$row_sale['p_price'];
                                $p_brand=$row_sale['p_brand'];
                                $p_image1=$row_sale['p_image1'];
                                $p_image2=$row_sale['p_image2'];
                                $p_image3=$row_sale['p_image3'];
                                $p_detail=$row_sale['p_detail'];
                                $p_type=$row_sale['p_type'];
                                $fg_udetail="select * from tbl_user where u_id='$user_id'";
                                $run_udetail=mysqli_query($con,$fg_udetail);
                                $row_udetail=mysqli_fetch_array($run_udetail);
                                $latitude=$row_udetail['latitude'];
                                $longitude=$row_udetail['longitude'];
                            ?>
                            <div class="product-item mb-50">
                                <div class="product-thumb">
                                    <a href="#">
                                        <img src="upload_image/<?php echo $p_image1 ?>" alt="">
                                    </a>
                                </div>
                                <div class="product-content">
                                    <h5 class="product-name">
                                        <a href="#"><?php echo $p_title ?></a>
                                    </h5>
                                    <div class="price-box">
                                        <span class="price-regular">Rs <?php echo number_format($p_price) ?></span>
                                    </div>
                                    <div class="product-action-link">
                                        <a href="bid_now.php?pid=<?php echo $post_id ?>&bstart=<?php echo $p_price ?>" data-bs-toggle="tooltip" title="Bid Now"><i class="fas fa-gavel"></i></a>
                                        
                                        <a href="#" data-bs-toggle="modal" data-bs-target="#quick_view"> <span data-bs-toggle="tooltip"
                                            title="Chat Now"><i class="fas fa-comments"></i></span> </a>
                                            <a href="https://www.google.com/maps/?q= <?php echo $latitude ?>,<?php echo $longitude ?>" target="_blank" data-bs-toggle="tooltip" title="Store Navigation"><i class="ion-location"></i></a>
                                    </div>
                                </div>
                            </div>
                        <?php } ?>
                        </div>
                    </div>
                </div>
            </div>
        </section>
    </main>
<?php include("footer.php");?>