<?php include("header.php");?>

  <div class="content-wrapper">
    <section class="content-header">
      <h1>
        All Orders 
      </h1>
      <ol class="breadcrumb">
        <li class="breadcrumb-item"><a href="#"><i class="fa fa-dashboard"></i> Home</a></li>
        <li class="breadcrumb-item"><a href="#">Orders</a></li>
        <li class="breadcrumb-item active">Order List</li>
      </ol>
    </section>
    <section class="content">
      <div class="row">
        <div class="col-12">
          <div class="box box-solid bg-dark">
          <div class="box-body">
				<div class="table-responsive">
				  <table border="1" style="width:100%">
					<thead>
						<tr style="background-color:skyblue;color:black;">
							<th><center>Id</center></th>
              <th><center>Email</center></th>
              <th><center>Order Amount</center></th>
              <th><center>Note</center></th>
              <th><center>Date</center></th>
              <th><center>Phone</center></th>
              <th><center>Address</center></th>
						</tr>
					</thead>
					<tbody>
<?php 

$feth_user="SELECT user_id,order_amount,order_note,bill_date,user_phone,user_address FROM `tbl_orders`";
$run_us=mysqli_query($con,$feth_user);
$index=1;
while($rows=mysqli_fetch_array($run_us))
{
$order_id=$rows['order_id'];
$user_id=$rows['user_id'];$user_id=$rows['user_id'];
$order_amount=$rows['order_amount'];
$order_note=$rows['order_note'];
$bill_date=$rows['bill_date'];
$user_phone=$rows['user_phone'];
$user_address=$rows['user_address'];

echo "
  <tr style='padding:5px'>
	<td><center style='color:black;padding:5px'>$order_id</center></td>
  <td><center style='color:black;padding:5px'>$user_id</center></td>
  <td><center style='color:black;padding:5px'>$order_amount</center></td>
  <td><center style='color:black;padding:5px'>$order_note</center></td>
  <td><center style='color:black;padding:5px'>$bill_date</center></td>
  <td><center style='color:black;padding:5px'>$user_phone</center></td>
  <td><center style='color:black;padding:5px'>$user_address</center></td>	
  </tr>
";
}
?>
				</tbody>
				</table>
				</div>              
          </div>
          </div>
        </div>
      </div>
    </section>
  </div>
<?php include("footer.php");?>