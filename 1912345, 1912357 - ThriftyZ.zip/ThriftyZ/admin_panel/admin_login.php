<?php session_start();
include("../function/function.php");
?>

<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="utf-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no">
  <meta name="description" content="MM Paint Admin Panel">
  <meta name="author" content="">
  <link rel="icon" href="http://crypto-admin-templates.multipurposethemes.com/images/favicon.ico">

  <title> ThriftyZ || Admin Panel  </title>
  
	<link rel="stylesheet" href="assets/vendor_components/bootstrap/dist/css/bootstrap.min.css">
  <link rel="stylesheet" href="css/bootstrap-extend.css">
	<link rel="stylesheet" href="css/master_style.css">
	<link rel="stylesheet" href="css/skins/_all-skins.css">	

</head>

<style>
.login-page, .register-page {
    background: url('images/background.jpg') center center no-repeat #d2d6de;
    background-size: cover;
    height: 100%;
    width: 100%;
    position: fixed;
}
</style>

<body class="hold-transition login-page" >

<div class="login-box" >
  <div class="login-logo">
    <a href=""><b>ThriftyZ</b><br> Admin Panel</a>
  </div>
  <div class="login-box-body">
    <p class="login-box-msg">Sign in</p>

    <form  method="post" class="form-element">
      <div class="form-group has-feedback">
        <input type="email" class="form-control" name="aemail" placeholder="Email">
        <span class="ion ion-email form-control-feedback"></span>
      </div>
      <div class="form-group has-feedback">
        <input type="password" class="form-control" name="apass" placeholder="Password">
        <span class="ion ion-locked form-control-feedback"></span>
      </div>
      <div class="row">
       
        <div class="col-12 text-center">
          <input type="submit" class="btn btn-info btn-block margin-top-10" name="btnlogin" value="SIGN IN">
        </div>
      </div>
    </form>
  </div>
</div>

<?php

if(isset($_POST['btnlogin']))
{

$email=$_POST['aemail'];
$pass=$_POST['apass'];

$check_avail="select * from tbl_admin_user where admin_email='$email' AND admin_pass='$pass'";
$run_avail=mysqli_query($con,$check_avail);
$cn_a=mysqli_num_rows($run_avail);

if($cn_a !=0)
{
$row_avail=mysqli_fetch_array($run_avail);
$aid=$row_avail['admin_id'];
$aname=$row_avail['admin_name'];
$_SESSION['aemail']=$email;
$_SESSION['aid']=$aid;
$_SESSION['aname']=$aname;
echo "<script>alert('Login Successfully')</script>";
echo "<script>window.open('index.php','_self')</script>";
}
else
{
echo "<script>alert('Email Id or Pass Is Incorrect')</script>";
echo "<script>window.open('admin_login.php','_self')</script>";
}
}
?>
	<script src="assets/vendor_components/jquery/dist/jquery.min.js"></script>
	<script src="assets/vendor_components/popper/dist/popper.min.js"></script>
	<script src="assets/vendor_components/bootstrap/dist/js/bootstrap.min.js"></script>
</body>
</html>