<?php include("header.php");

 $ipaddress = '';
    if (getenv('HTTP_CLIENT_IP'))
        $ipaddress = getenv('HTTP_CLIENT_IP');
    else if(getenv('HTTP_X_FORWARDED_FOR'))
        $ipaddress = getenv('HTTP_X_FORWARDED_FOR');
    else if(getenv('HTTP_X_FORWARDED'))
        $ipaddress = getenv('HTTP_X_FORWARDED');
    else if(getenv('HTTP_FORWARDED_FOR'))
        $ipaddress = getenv('HTTP_FORWARDED_FOR');
    else if(getenv('HTTP_FORWARDED'))
       $ipaddress = getenv('HTTP_FORWARDED');
    else if(getenv('REMOTE_ADDR'))
        $ipaddress = getenv('REMOTE_ADDR');
    else
        $ipaddress = 'UNKNOWN';

$ipdat = @json_decode(file_get_contents(
    "http://www.geoplugin.net/json.gp?ip=" . $ipaddress));

$city_name=$ipdat->geoplugin_city;
$latitude=$ipdat->geoplugin_latitude;
$longitude=$ipdat->geoplugin_longitude;
 ?>

    <main>
        <div class="breadcrumb-area bg-img" data-bg="assets/img/banner/breadcrumb-banner.webp">
            <div class="container">
                <div class="row">
                    <div class="col-12">
                        <div class="breadcrumb-wrap text-center">
                            <nav aria-label="breadcrumb">
                                <h1 class="breadcrumb-title">Register Yourself</h1>
                                
                            </nav>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="login-register-wrapper section-padding">
            <div class="container">
                <div class="member-area-from-wrap">
                    <div class="row">
                    <div class="col-lg-3"></div>
                        <div class="col-lg-6">
                            <div class="login-reg-form-wrap signup-form">
                                <h2>Sign up</h2>
                                <form  method="post">
                                    <input type="hidden" name="latitude" id="latitude" value="<?php echo $latitude ?>">
                                    <input type="hidden" name="longitude" id="longitude" value="<?php echo $longitude ?>">
                                    <div class="single-input-item">
                                        <input type="text" placeholder="Full Name" required name="uname" />
                                    </div>

                                    <div class="single-input-item" >
                                        <input type="email" placeholder="Enter your Email" name="uemail" required />
                                    </div>
                                    <div class="row">
                                        <div class="col-lg-6">
                                            <div class="single-input-item">
                                                <input type="password" placeholder="Enter your Password" required name="upass" />
                                            </div>
                                        </div>
                                        <div class="col-lg-6">
                                            <div class="single-input-item">
                                                <input type="number" placeholder="Phone No" required name="uphone" />
                                            </div>
                                        </div>
                                    </div>
                                    <div class="single-input-item">
                                        <input type="text" placeholder="Enter your Address" name="uaddress" required />
                                    </div>
                                     <div class="single-input-item">
                                       <select class="form-control" name="utype" id="utype" required="">
                                           <option value="" hidden="">Select User Type</option>
                                           <option>Buyer</option>
                                           <option>Seller</option>
                                       </select>
                                       <input type="text" placeholder="Enter your ShopName" name="shopname" id="shopname"  />
                                    </div>
                                    <br>
                                    <div class="single-input-item">
                                        <div class="login-reg-form-meta">
                                            <div class="remember-meta">
                                                <div class="custom-control custom-checkbox">
                                                  <p>Already Have an Account ? <a href="user_login.php">Login Now</a></p>                                                 </div>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="single-input-item">
                                        <button class="btn" name="btn_register" type="submit">Register</button>
                                    </div>
                                </form>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </main>
<?php include("footer.php"); ?>
<script type="text/javascript">
    $('#shopname').hide();
  $('#utype').change(function(){
    var utype=$('#utype').val();
    if(utype == "Seller")
    {
        $('#shopname').show();
    }
    else{
        $('#shopname').hide();
    }
  });

</script>
 <script>
   if (navigator.geolocation) {
    navigator.geolocation.getCurrentPosition(showPosition);
  }
  function showPosition(position) {
    $('#latitude').val(position.coords.latitude);
    $('#longitude').val(position.coords.longitude);
 
}
    </script>

<?php 
if(isset($_POST['btn_register']))
{
$uname=$_POST['uname'];
$uemail=$_POST['uemail'];
$upass=$_POST['upass'];
$uphone=$_POST['uphone'];
$uaddress=$_POST['uaddress'];
$utype=$_POST['utype'];
$shopname=$_POST['shopname'];
$latitude=$_POST['latitude'];
$longitude=$_POST['longitude'];

$check="select * from tbl_user where u_email='$uemail'";
$run_check=mysqli_query($con,$check);
$row_check=mysqli_num_rows($run_check);
if($row_check == 0)
{
  $ins="INSERT INTO `tbl_user`(u_name,u_email,u_pass,u_phone,u_address,u_type,shopname,latitude,longitude) VALUES ('$uname','$uemail','$upass','$uphone','$uaddress','$utype','$shopname','$latitude','$longitude')";
  $run_ins=mysqli_query($con,$ins);
  if($run_ins)
  {
    echo "<script>alert('Register Successfully')</script>";
    echo "<script>window.open('email_send.php?uemail=$uemail','_self')</script>";
  }
  else{
    echo "<script>alert('Register Un Successfully')</script>";
    echo "<script>window.open('user_register.php','_self')</script>";
  }
}
else{
    echo "<script>alert('Email Already Exist')</script>";
    echo "<script>window.open('user_register.php','_self')</script>";
}   
}
?>