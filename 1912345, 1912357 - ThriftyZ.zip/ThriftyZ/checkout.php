<?php include("header.php"); 
if(isset($_SESSION['uemail']))
{
$uemail=$_SESSION['uemail'];
$fg_get="SELECT u_name,u_phone,u_address FROM `tbl_user` where u_email='$uemail'";
$run_get=mysqli_query($con,$fg_get);
$row_get=mysqli_fetch_array($run_get);
$u_name=$row_get['u_name'];
$u_phone=$row_get['u_phone'];
$u_address=$row_get['u_address'];
}
else{
	echo "<script>window.open('user_login.php','_self')</script>";
}

$oamount=$_GET['oamount'];
?>
        <div class="breadcrumb-area bg-img" data-bg="assets/img/banner/breadcrumb-banner.jpg">
            <div class="container">
                <div class="row">
                    <div class="col-12">
                        <div class="breadcrumb-wrap text-center">
                            <nav aria-label="breadcrumb">
                                <h1 class="breadcrumb-title">Checkout</h1>
                                <br>
                            </nav>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="checkout-page-wrapper ">
            <div class="container">
               
                <div class="row">
                    <div class="col-lg-2"></div>
                    <div class="col-lg-8">
                        <div class="checkout-billing-details-wrap">
                            <h4 class="checkout-title">Billing Details</h4>
                            <div class="billing-form-wrap">
                                <form method="post">
                                    <div class="row">
                                    	<input type="hidden" value="<?php echo $oamount ?>" name="oamount">
                                        <div class="col-md-6">
                                            <div class="single-input-item">
                                                <label for="f_name" class="required">First Name</label>
                                                <input type="text" id="f_name" name="uname" placeholder="First Name" required value="<?php echo $u_name ?>" />
                                            </div>
                                        </div>

                                        <div class="col-md-6">
                                            <div class="single-input-item">
                                                <label for="l_name" class="required">Email Address</label>
                                                <input type="text" name="uemail" id="l_name" placeholder="Email" value="<?php echo $uemail ?>" readonly />
                                            </div>
                                        </div>

                                        <div class="col-md-6">
                                        <div class="single-input-item">
                                        <label for="country" class="required">Country</label>
                                        <select name="country nice-select" id="country" name="ucountry">
                                            <option value="Pakistan">Pakistan</option>
                                            <option value="Afghanistan">Afghanistan</option>
                                            <option value="Albania">Albania</option>
                                            <option value="Algeria">Algeria</option>
                                            <option value="Armenia">Armenia</option>
                                            <option value="Bangladesh">Bangladesh</option>
                                            <option value="India">India</option>
                                            
                                            <option value="England">England</option>
                                            <option value="London">London</option>
                                            <option value="London">London</option>
                                            <option value="Chaina">China</option>
                                        </select>
                                    </div>
                                        </div>
                                        <div class="col-md-6">
                                        	 <div class="single-input-item">
                                        <label for="street-address" class="required ">Street address</label>
                                        <input type="text" id="street-address" placeholder="Street address Line 1" required name="uaddress" value="<?php echo $u_address ?>" />
                                    </div>
                                        </div>
                                        <div class="col-md-4">
                                        	<div class="single-input-item">
                                        <label for="town" class="required">Town / City</label>
                                        <input type="text" id="town" name="ucity" placeholder="Town / City" required />
                                    </div>
                                        </div>
                                        <div class="col-md-4">
                                        	<div class="single-input-item">
                                        <label for="state">State / Divition</label>
                                        <input type="text" id="state" name="ustate" placeholder="State / Divition" />
                                    </div>
                                        </div>
                                        <div class="col-md-4">
                                        	<div class="single-input-item">
                                        <label for="phone">Phone</label>
                                        <input type="text" id="phone" name="uphone" value="<?php echo $u_phone ?>" placeholder="Phone" />
                                    </div>
                                        </div>
                                        <div class="col-md-12">
                                        <div class="single-input-item">
                                        <label for="ordernote">Order Note</label>
                                        <textarea  id="ordernote" name="unote" cols="30" rows="3" placeholder="Notes about your order, e.g. special notes for delivery."></textarea>
                                    </div>
                                     <button type="submit" name="btnsubmit" class="btn btn-sqr">Place Order</button>
                                     <br><br><br><br><br><br>
                                         </div>
                                    </div>
                                </form>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>    

<?php include("footer.php"); ?>
<?php 

if(isset($_POST['btnsubmit']))
{
    $uname=$_POST['uname'];
    $uemail=$_POST['uemail'];
    $ucountry=mysqli_real_escape_string($con,$_POST['ucountry']);
    $uaddress=mysqli_real_escape_string($con,$_POST['uaddress']);
    $ucity=mysqli_real_escape_string($con,$_POST['ucity']);
    $ustate=mysqli_real_escape_string($con,$_POST['ustate']);
    $uphone=mysqli_real_escape_string($con,$_POST['uphone']);
    $unote=mysqli_real_escape_string($con,$_POST['unote']);
    $oamount=mysqli_real_escape_string($con,$_POST['oamount']);
    
    $ins_ord="INSERT INTO tbl_orders(user_id,order_amount,order_note,bill_date,user_phone,user_address,user_city,user_state) VALUES ('$uemail','$oamount','$unote',NOW(),'$uphone','$uaddress','$ucity','$ustate')";
$run_ord=mysqli_query($con,$ins_ord);
$max_pr="select * from tbl_orders order by order_id desc limit 1";
$run_pr=mysqli_query($con,$max_pr);
$row_pr=mysqli_fetch_array($run_pr);
$oids=$row_pr['order_id'];

$total=0;
$dc=0;
foreach ($_SESSION['mycart'] as $i => $value) {

$fet_pro="select * from tbl_upload_for_sale where post_id='$i'";
$run_pro=mysqli_query($con,$fet_pro);
$row_pro=mysqli_fetch_array($run_pro);
$pname=$row_pro['p_title'];
$selling_price=$row_pro['p_price'];
$pqty=$value['q'];

$ins_pro="INSERT INTO tbl_order_detail(order_id,product_id,product_name,selling_price,order_qty,order_date) VALUES ('$oids','$i','$pname','$selling_price','$pqty',NOW())";

$run_pro=mysqli_query($con,$ins_pro);

unset($_SESSION['mycart'][$i]);

if($run_pro)
{
    echo "<script>alert('Order Place Successfully')</script>";
    echo "<script>window.open('index.php','_self')</script>";
}

else {
    echo "<script>alert('Order Place Not Successfully')</script>";
    echo "<script>window.open('checkout.php?oamount=$oamount','_self')</script>";
}
}
}
?>