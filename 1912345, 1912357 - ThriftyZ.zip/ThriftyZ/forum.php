<?php include("header.php");
if(!isset($_SESSION['uemail']))
{
echo "<script>window.open('user_login.php','_self')</script>";
}
?>
<main>
<div class="breadcrumbs-area position-relative">
        <div class="container">
            <div class="row">
                <div class="col-6 col-sm-6 ">
                    <div class="breadcrumb-content  section-content">
                        <h3 class="title-3">FORUM</h3>
                        <br>
                    </div>
                </div>

                <div class="col-6 col-sm-6 text-right">
                    <div class="breadcrumb-content  section-content" style="text-align: right">
                        <a href="add_forum_question.php" class="btn btn-warning" >+Add Query</a>
                        <br>
                    </div>
                </div>
            </div>
        </div>
    </div>
     <div class="shop-main-wrapper section-padding">
            <div class="container">
                <div class="row">
                    <div class="col-12">
                        <div class="shop-product-wrapper">
                            <div class="shop-product-wrap list-view row mbn-50">
                            <?php 
                            $fg_shoe="SELECT * FROM `tbl_forum_question` order by question_id desc";
                            
                            $run_shoe=mysqli_query($con,$fg_shoe);
                            $cn_shoe=mysqli_num_rows($run_shoe);
                            
                            while($row_shoe=mysqli_fetch_array($run_shoe))
                            {
                                $question_id=$row_shoe['question_id'];
                                $user_name=$row_shoe['user_name'];
                                $question_title=$row_shoe['question_title'];
                                $question_detail=$row_shoe['question_detail'];
                                $question_date=$row_shoe['question_date'];

                            ?>
                                <div class="col-xl-3 col-lg-4 col-sm-6">
                                    <div class="product-list-item mb-30">
                                        <div class="product-thumb">
                                            <a href="#">
                                                <img src="assets/img/discussion.png" alt="product thumb">
                                            </a>
                                        </div>
                                        <div class="product-content-list">
                                            <h5 class="product-name">
                                                <a href="#"><?php echo $question_title ?></a>
                                            </h5>
                                            <p><?php echo $question_detail ?></p>
                                            <p><b>Post By : </b><?php echo $user_name ?> On <b><?php echo $question_date ?></b></p>
                                            <div class="product-link-2 position-static">
                                               
                                                <a href="forum_detail.php?qid=<?php echo $question_id ?>" data-bs-toggle="tooltip" title="Question Detail"><i class="ion-eye"></i></a>
                                                
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            <?php  } ?>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </main>
<?php include("footer.php");?>