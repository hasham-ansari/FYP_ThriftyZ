<?php include("header.php"); 
if(isset($_SESSION['uemail']) && $_SESSION['utype'] == "Buyer")
{
$uemail=$_SESSION['uemail'];
}
else{
	echo "<script>window.open('user_login.php','_self')</script>";
}
?>
<main>
        <div class="breadcrumb-area bg-img" data-bg="assets/img/banner/breadcrumb-banner.webp">
            <div class="container">
                <div class="row">
                    <div class="col-12">
                        <div class="breadcrumb-wrap text-center">
                            <nav aria-label="breadcrumb">
                                <h1 class="breadcrumb-title">My Orders</h1>
                               
                            </nav>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="my-account-wrapper section-padding">
            <div class="container custom-container">
                <div class="row">
                    <div class="col-lg-12">
                        <div class="myaccount-page-wrapper">
                            <div class="row">
                                <div class="col-lg-3 col-md-4">
                                    <div class="myaccount-tab-menu nav" role="tablist">
                                        <a href="buyer_dashboard.php" role="tab" aria-controls="dashboard" aria-selected="false">
                                            <i class="fa fa-dashboard"></i>
                                            Dashboard
                                        </a>

                                        <a href="mycart.php" id="download_btn"  role="tab" aria-controls="download" aria-selected="false">
                                            <i class="fa fa-cart-plus"></i>
                                            My Cart
                                        </a>

                                        <a href="buyer_myorder.php" class="active" id="download_btn"  role="tab" aria-controls="download" aria-selected="false">
                                            <i class="fa fa-cart-plus"></i>
                                           Orders
                                        </a>

                                        <a href="my_bids.php" id="download_btn"  role="tab" aria-controls="download" aria-selected="false">
                                            <i class="fa fa-cart-plus"></i>
                                           My Bids
                                        </a>

                                        <a href="my_winbids.php" id="download_btn"  role="tab" aria-controls="download" aria-selected="false">
                                            <i class="fa fa-credit-card"></i>
                                           Win Bids
                                        </a>

                                        <a href="my_chat.php" id="download_btn"  role="tab" aria-controls="download" aria-selected="false">
                                            <i class="far fa-comment"></i>
                                           Chat
                                        </a>

                                        <a href="user_logout.php"><i class="fa fa-sign-out"></i> Logout</a>
                                    </div>
                                </div>
        
                                <div class="col-lg-9 col-md-8">
                                    <div class="tab-content" id="myaccountContent">
                                     <table border="1" style="width:100%">
                                         <tr style="text-align: center;border:1px solid black">
                                             <th style="border:1px solid black">Order Id</th>
                                             <th style="border:1px solid black">Order Date</th>
                                             <th style="border:1px solid black">Bill Amount</th>
                                         </tr>
                                        <?php 
                    $fg_order="SELECT order_amount,bill_date,order_status,order_id FROM `tbl_orders` where user_id='$uemail'";
                    $run_order=mysqli_query($con,$fg_order);
                    while($row_order=mysqli_fetch_array($run_order))
                    {
                        $order_amount=$row_order['order_amount'];
                        $bill_date=$row_order['bill_date'];
                        $order_status=$row_order['order_status'];
                        $order_id=$row_order['order_id'];

                    echo "
                    <tr style='border:1px solid black'>
                    <td style='border:1px solid black'><center>$order_id</center></td>
                    <td style='border:1px solid black'><center>$bill_date</center></td>
                    <td style='border:1px solid black'><center>$order_amount</center></td>
                    </tr>
                    ";
                    }                    
                    ?> 
                                    </table>   
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </main>
<?php include("footer.php"); ?>