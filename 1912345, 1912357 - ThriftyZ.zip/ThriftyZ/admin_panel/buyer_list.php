<?php include("header.php");?>
  <div class="content-wrapper">
    <section class="content-header">
      <h1>
        Buyers
      </h1>
      <ol class="breadcrumb">
        <li class="breadcrumb-item"><a href="#"><i class="fa fa-dashboard"></i> Home</a></li>
        <li class="breadcrumb-item"><a href="#">Registered Users</a></li>
        <li class="breadcrumb-item">Buyer's List</li>
      </ol>
    </section>
    <section class="content">
      <div class="row">
        <div class="col-12">
         
          <div class="box box-solid bg-dark">
            <div class="box-header with-border">
             
            </div>
            <div class="box-body">
				  <div class="table-responsive">
				  <table border="1" style="width:100%">
					<thead>
						<tr style="background-color:skyblue;color:black;">
							<th><center>Id</center></th>
              <th><center>Name</center></th>
              <th><center>Email</center></th>
              <th><center>Password</center></th>
              <th><center>Phone</center></th>
              <th><center>Address</center></th>
						<th>Action</th>
						</tr>
					</thead>
					<tbody>
<?php 

$feth_user="select * from tbl_user where u_type='Buyer' ";
$run_us=mysqli_query($con,$feth_user);

$index=1;
while($rows=mysqli_fetch_array($run_us))
{
$u_id=$rows['u_id'];
$u_name=$rows['u_name'];
$u_email=$rows['u_email'];
$u_pass=$rows['u_pass'];
$u_phone=$rows['u_phone'];
$u_address=$rows['u_address'];

echo "

<tr style='padding:5px'>
<td><center style='color:black;padding:5px'>$index</center></td>
<td><center style='color:black;padding:5px'>$u_name</center></td>
<td><center style='color:black;padding:5px'>$u_email</center></td>
<td><center style='color:black;padding:5px'>$u_pass</center></td>
<td><center style='color:black;padding:5px'>$u_phone</center></td>
<td><span style='color:black;padding:5px'>$u_address</span></td>
<td>
<a href='?iids=$u_id' style='color:black;padding:5px' class='text-danger'>Delete</a> 
||
<a href='edit_buyer.php?uid=$u_id' style='color:black;padding:5px' class='text-success'>Update</a> 
</td>
</tr>

";
$index =$index + 1;
}
?>
					</tbody>				  
				  </table>
				  </div>              
          </div>
          </div>
        </div>
      </div>
    </section>
  </div>
  <?php include("footer.php");?>
  <?php

if(isset($_GET['iids']))
{
	$catid=$_GET['iids'];
	$del_cat="delete from tbl_user where u_id='$catid'";
	$run_del=mysqli_query($con,$del_cat);
  if($run_del)
  {
	  echo "<script>alert('Buyer  Successfully Deleted')</script>";
	  echo "<script>window.open('buyer_list.php','_self')</script>";
  }

  else {
	  echo "<script>alert('Buyer Not Successfully Deleted')</script>";
	  echo "<script>window.open('buyer_list.php','_self')</script>";
  }
}
?>