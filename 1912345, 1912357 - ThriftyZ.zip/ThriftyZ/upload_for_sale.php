<?php include("header.php"); 
if(isset($_SESSION['uemail']) && $_SESSION['utype'] == "Seller")
{

}
else{
	echo "<script>window.open('user_login.php','_self')</script>";
}
?>
    <main>
        <div class="breadcrumb-area bg-img" data-bg="assets/img/banner/breadcrumb-banner.webp">
            <div class="container">
                <div class="row">
                    <div class="col-12">
                        <div class="breadcrumb-wrap text-center">
                            <nav aria-label="breadcrumb">
                                <h1 class="breadcrumb-title">My Account</h1>
                            </nav>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="my-account-wrapper section-padding">
            <div class="container custom-container">
                <div class="row">
                    <div class="col-lg-12">
                        <div class="myaccount-page-wrapper">
                            <div class="row">
                                <div class="col-lg-3 col-md-4">
                                    <div class="myaccount-tab-menu nav" role="tablist">
                                        <a href="seller_dashboard.php" class="" id="download_btn"  role="tab" aria-controls="download" aria-selected="false">
                                            <i class="fa fa-dashboard"></i>
                                            Dashboard
                                        </a>
                                       
                                        <a href="upload_for_sale.php" class="active" id="download_btn"  role="tab" aria-controls="download" aria-selected="false">
                                            <i class="fa fa-cloud-download"></i>
                                            Upload for Sale
                                        </a>
                                           <a href="upload_for_bidding.php"  id="download_btn"  role="tab" aria-controls="download" aria-selected="false">
                                            <i class="fa fa-cloud-download"></i>
                                            Upload for Bidding
                                        </a>
                                        
                                        <a href="seller_myorder.php" id="download_btn" role="tab" aria-controls="download" aria-selected="false">
                                            <i class="fa fa-cart-arrow-down"></i> 
                                            Orders
                                        </a>
                                     
                                        <a href="seller_mybidding.php" id="download_btn"  role="tab" aria-controls="download" aria-selected="false">
                                         <i class="fas fa-gavel"></i>
                                        &nbsp;   Bidding
                                        </a>

                                        <a href="my_chat2.php" id="download_btn"  role="tab" aria-controls="download" aria-selected="false">
                                            <i class="far fa-comment"></i>
                                         &nbsp;  Chat
                                        </a>
                                           
                                        <a href="user_logout.php"><i class="fa fa-sign-out"></i> Logout</a>
                                    </div>
                                </div>
                                <div class="col-lg-9 col-md-8">
                                    <div class="tab-content" id="myaccountContent">
                                        <div class="tab-pane fade show active" id="account-info" role="tabpanel" aria-labelledby="account-info_btn">
                                            <div class="myaccount-content">
                                                <h3>Upload For Sold</h3>
                                                <div class="account-details-form">
                                                    <form method="post" enctype="multipart/form-data" >
                                                       <div class="single-input-item">
                                                            <label for="display-name" class="required">Product Title</label>
                                                            <input type="text" id="display-name" placeholder="Display Name" name="utitle" />
                                                        </div>
                                                        <div class="row">
                                                            <div class="col-lg-6">
                                                                <div class="single-input-item">
                                                                    <label for="first-name" class="required">Price</label>
                                                                    <input type="number" id="first-name" placeholder="Price" name="uprice" />
                                                                </div>
                                                            </div>
                                                       <div class="col-lg-6">
                                                                <div class="single-input-item">
                                                                    <label for="last-name" class="required">Brand</label>
                                                       <select class="form-control" required="" name="ubrand">
                                                       	<option value="" hidden="">Select Brand</option>
                                                       	<?php
                                                       	$fg_brand="select * from tbl_brand";
                                                       	$run_brand=mysqli_query($con,$fg_brand);
                                                       	while($row_brand=mysqli_fetch_array($run_brand))
                                                       	{
                                                       		$brand_id=$row_brand['brand_id'];
                                                       		$brand_name=$row_brand['brand_name'];
                                                       		echo "<option value='$brand_id'>$brand_name</option>";
                                                       	} 
                                                       	?>
                                                       </select>
                                                                </div>
                                                            </div>
                                                        </div>
                                                        <div class="row">
                                                            <div class="col-lg-6">
                                                                <div class="single-input-item">
                                                                    <label for="first-name" class="required">Image 1</label>
                                                                    <input type="file" id="first-name" placeholder="image" name="image_1" />
                                                                </div>
                                                            </div>
                                                            <div class="col-lg-6">
                                                                <div class="single-input-item">
                                                                    <label for="first-name" class="required">Image 2</label>
                                                                    <input type="file" id="first-name" placeholder="image" name="image_2" />
                                                                </div>
                                                            </div>
                                                            <div class="col-lg-6">
                                                                <div class="single-input-item">
                                                                    <label for="first-name" class="required">Image 3</label>
                                                                    <input type="file" id="first-name" placeholder="image" name="image_3" />
                                                                </div>
                                                            </div>
                                                       <div class="col-lg-6">
                                                                <div class="single-input-item">
                                                                    <label for="last-name" class="required">Type</label>
                                                       <select class="form-control" required="" name="utype" required="">
                                                       	<option >For Boys</option>
                                                       	<option >For Girls</option>
                                                      
                                                       </select>
                                                                </div>
                                                            </div>
                                                        </div>
                                                        
                                                        <div class="single-input-item">
                                                            <label for="email" class="required">Detail</label>
                                                            <input type="text" id="udetail" name="udetail" placeholder="Enter Detail" />
                                                        </div>
                                                      
                                                        <div class="single-input-item">
                                                            <button type="submit" name="btn_upload" class="btn btn-warning">Upload</button>
                                                        </div>
                                                    </form>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </main>
<?php include("footer.php"); ?>
<?php 


if(isset($_POST['btn_upload']))
{

$utitle=mysqli_real_escape_string($con,$_POST['utitle']);
$uprice=mysqli_real_escape_string($con,$_POST['uprice']);
$ubrand=mysqli_real_escape_string($con,$_POST['ubrand']);
$utype=mysqli_real_escape_string($con,$_POST['utype']);
$udetail=mysqli_real_escape_string($con,$_POST['udetail']);

$image_1=$_FILES['image_1']['name'];
$image_tmp1=$_FILES['image_1']['tmp_name'];

$image_2=$_FILES['image_2']['name'];
$image_tmp2=$_FILES['image_2']['tmp_name'];

$image_3=$_FILES['image_3']['name'];
$image_tmp3=$_FILES['image_3']['tmp_name'];
$uid=$_SESSION['uid'];

  move_uploaded_file($image_tmp1,"upload_image/$image_1");
  move_uploaded_file($image_tmp2,"upload_image/$image_2");
  move_uploaded_file($image_tmp3,"upload_image/$image_3");

$insert="INSERT INTO tbl_upload_for_sale(user_id,p_title,p_price,p_brand,p_image1,p_image2,p_image3,p_type,p_detail) VALUES ('$uid','$utitle','$uprice','$ubrand','$image_1','$image_2','$image_3','$utype','$udetail')";
$runs=mysqli_query($con,$insert);

if($runs){
echo "<script>alert('Upload Successfully')</script>";
echo "<script>window.open('upload_for_sale.php','_self')</script>";
}

else {
echo "<script>alert('Upload Not Successfully')</script>";
echo "<script>window.open('upload_for_sale.php','_self')</script>";
}
}
?>