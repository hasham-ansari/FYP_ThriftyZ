<?php session_start();include("function/function.php"); error_reporting(0);?>
<!DOCTYPE html>
<html class="no-js" lang="zxx">

<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="meta description">
    <title>ThriftyZ - Online Shoes Buying & Selling</title>
    <link rel="shortcut icon" href="assets/img/favicons.png" type="image/x-icon" />
    <link href="assets/css/plugins.css" rel="stylesheet">
    <link href="assets/css/vendor.css" rel="stylesheet">
    <link href="assets/css/style.css" rel="stylesheet">
    <link rel="stylesheet" href="assets/css/vendor/bootstrap.min.css">
    <script src="assets/js/modernizr-2.8.3.min.js"></script>
    <script src="https://kit.fontawesome.com/51238610b6.js" crossorigin="anonymous"></script>
   
</head>

<body>
    <header class="header-area">
        <div class="main-header d-none d-lg-block">
            <div class="header-top theme-bg">
                <div class="container">
                    <div class="row align-items-center">
                        <div class="col-lg-6">
                            <div class="welcome-message">
                                <p>Welcome to ThriftyZ</p>
                            </div>
                        </div>
                        <div class="col-lg-6 text-end">
                            <div class="header-top-settings">
                                <ul class="nav align-items-center justify-content-end">
                                    <li class="curreny-wrap">
                                       <i class="fa fa-envelope" aria-hidden="true"></i> &nbsp; info@thrift.com.pk
                                    </li>
                                    <li class="curreny-wrap">
                                       <i class="fa fa-phone" aria-hidden="true"></i> &nbsp; +92 331 3913133
                                        
                                    </li>
                                    
                                </ul>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            <div class="header-main-area sticky">
                <div class="container">
                    <div class="row align-items-center position-relative">
                        <div class="col-lg-2">
                            <div class="logo">
                                <a href="index.php">
                                    <img src="assets/img/logo/logo2.png" alt="">
                                </a>
                            </div>
                        </div>

                        <div class="col-lg-8 position-static">
                            <div class="main-menu-area">
                                <div class="main-menu">
                                    <nav class="desktop-menu">
                                        <ul>
                                            <li class="active"><a href="index.php">Home</a>
                                            </li>
                                             <li><a href="allshoes.php">Shoes <i class="fa fa-angle-down"></i></a>
                                                <ul class="dropdown">
                                                   <?php 
                                                  $fg_brand="select * from tbl_brand";
                                                  $run_brand=mysqli_query($con,$fg_brand);
                                                  while($row_brand=mysqli_fetch_array($run_brand))
                                                  {
                                                    $brand_id=$row_brand['brand_id'];
                                                    $brand_name=$row_brand['brand_name'];
                                                    echo "<li><a href='shoes.php?bid=$brand_id'>$brand_name</a></li>";
                                                  }
                                                    ?>
                                                </ul>
                                            </li>
                                            <li><a href="allauction.php">Auction <i class="fa fa-angle-down"></i></a>
                                                <ul class="dropdown">
                                                   <?php 
                                                  $fg_brand="select * from tbl_brand";
                                                  $run_brand=mysqli_query($con,$fg_brand);
                                                  while($row_brand=mysqli_fetch_array($run_brand))
                                                  {
                                                    $brand_id=$row_brand['brand_id'];
                                                    $brand_name=$row_brand['brand_name'];
                                                    echo "<li><a href='auction.php?bid=$brand_id'>$brand_name</a></li>";
                                                  }?>
                                                   
                                                </ul>
                                            </li>
                                                                                       
                                          <li><a href="forum.php">Forum</a></li>
                                            <li><a href="contact_us.php">Contact us</a></li>
                                            <li><a href="chat_bot.php">ChatBot</a></li>
                                        </ul>
                                    </nav>
                                </div>
                            </div>
                        </div>
                        <div class="col-lg-2">
                            <div class="header-configure-wrapper">
                                <div class="header-configure-area">
                                    <ul class="nav justify-content-end">
                                        <li>
                                            <a href="#" class="offcanvas-btn">
                                                <i class="ion-ios-search-strong"></i>
                                            </a>
                                        </li>
                                        <li class="user-hover">
                                            <a href="#">
                                              <i class="fa fa-user" aria-hidden="true"></i>
                                            </a>
                                            <ul class="dropdown-list">
                                         <li> <?php
                                        if(isset($_SESSION['uemail']))
                                        {?>
                                        <?php if($_SESSION['utype']=="Seller"){ ?>
                                            <a  href="seller_dashboard.php">my account</a>
                                        <?php } else { ?>
                                            <a  href="buyer_dashboard.php">my account</a>
                                        <?php } ?></li>
                                        <li><a href="user_logout.php">Logout</a></li>
                                        <?php } else { ?>
                                                <li><a href="user_login.php">login</a></li>
                                                <li><a href="user_register.php">register</a></li>
                                            <?php } ?>
                                        </ul>
                                        </li>
                                        <li>
                                            <a href="mycart.php" class="">
                                            <i class="ion-bag"></i>
                                            <div class="notification">
                                            <?php 
                                            if(isset($_SESSION['mycart']))
                                            {
                                              echo count($_SESSION['mycart']);
                                            }
                                            else {
                                              echo "0";
                                            }
                                            ?>
                                            </div>
                                            </a>
                                        </li>
                                    </ul>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <div class="mobile-header d-lg-none d-md-block sticky">
            <div class="container">
                <div class="row align-items-center">
                    <div class="col-12">
                        <div class="mobile-main-header">
                            <div class="mobile-logo">
                                <a href="#">
                                    <img src="assets/img/logo/logo2.png" alt="Brand Logo">
                                </a>
                            </div>
                            <div class="mobile-menu-toggler">
                                <div class="mini-cart-wrap">
                                    <a href="#">
                                        <i class="ion-bag"></i>
                                    </a>
                                </div>
                                <div class="mobile-menu-btn">
                                    <div class="off-canvas-btn">
                                        <i class="ion-navicon"></i>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </header>
    <aside class="off-canvas-wrapper">
        <div class="off-canvas-overlay"></div>
        <div class="off-canvas-inner-content">
            <div class="btn-close-off-canvas">
                <i class="ion-android-close"></i>
            </div>
            <div class="off-canvas-inner">
                <div class="search-box-offcanvas">
                    <form>
                        <input type="text" placeholder="Search Here...">
                        <button class="search-btn"><i class="ion-ios-search-strong"></i></button>
                    </form>
                </div>
                <div class="mobile-navigation">
                    <nav>
                        <ul class="mobile-menu">
                            <li ><a href="index.php">Home</a>
                                
                            </li>
                            <li class="menu-item-has-children"><a href="#">Shoe's</a>
                                <ul class="dropdown">
                                    <?php 
                                        $fg_brand="select * from tbl_brand";
                                        $run_brand=mysqli_query($con,$fg_brand);
                                        while($row_brand=mysqli_fetch_array($run_brand))
                                        {
                                            $brand_id=$row_brand['brand_id'];
                                            $brand_name=$row_brand['brand_name'];
                                            echo "<li><a href='auction.php?bid=$brand_id'>$brand_name</a></li>";
                                        }
                                    ?>
                                </ul>
                                </li>
                                <li class="menu-item-has-children"><a href="#">Auction's</a>
                                <ul class="dropdown">
                                    <?php 
                                        $fg_brand="select * from tbl_brand";
                                        $run_brand=mysqli_query($con,$fg_brand);
                                        while($row_brand=mysqli_fetch_array($run_brand))
                                        {
                                            $brand_id=$row_brand['brand_id'];
                                            $brand_name=$row_brand['brand_name'];
                                            echo "<li><a href='auction.php?bid=$brand_id'>$brand_name</a></li>";
                                        }
                                    ?>
                                </ul>
                            </li>
                            <li><a href="#">Forum</a></li>
                            <li><a href="contact_us.php">Contact us</a></li>
                            <li><a href="chat_bot.php">ChatBot</a></li>
                        </ul>
                    </nav>
                </div>
                <div class="mobile-settings">
                    <ul class="nav">
                        <li>
                            <div class="dropdown mobile-top-dropdown">
                                <a href="#" class="dropdown-toggle" id="myaccount" data-bs-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                                    My Account
                                    <i class="fa fa-angle-down"></i>
                                </a>
                                <div class="dropdown-menu" aria-labelledby="myaccount">
                                          <?php
                                        if(isset($_SESSION['uemail']))
                                        {?>
                                        <?php if($_SESSION['utype']=="Seller"){ ?>
                                        <a class="dropdown-item" href="seller_dashboard.php">my account</a>
                                        <?php } else { ?>
                                        <a class="dropdown-item" href="buyer_dashboard.php">my account</a>
                                        <?php } ?>
                                        <a class="dropdown-item" href="user_logout.php">Logout</a>
                                        <?php } else { ?>
                                        <a class="dropdown-item" href="user_login.php">login</a>
                                        <a class="dropdown-item" href="user_register.php">register</a>
                                        <?php } ?>
                                </div>
                            </div>
                        </li>
                    </ul>
                </div>
                <div class="offcanvas-widget-area">
                    <div class="off-canvas-contact-widget">
                        <ul>
                            <li><i class="fa fa-mobile"></i>
                                <a href="#">+92 331 3913133</a>
                            </li>
                            <li><i class="fa fa-envelope-o"></i>
                                <a href="#">info@thrift.com.pk</a>
                            </li>
                        </ul>
                    </div>
                    <div class="off-canvas-social-widget">
                        <a href="#"><i class="fa fa-facebook"></i></a>
                        <a href="#"><i class="fa fa-twitter"></i></a>
                        <a href="#"><i class="fa fa-pinterest-p"></i></a>
                        <a href="#"><i class="fa fa-linkedin"></i></a>
                        <a href="#"><i class="fa fa-youtube-play"></i></a>
                    </div>
                </div>
            </div>
        </div>
    </aside>