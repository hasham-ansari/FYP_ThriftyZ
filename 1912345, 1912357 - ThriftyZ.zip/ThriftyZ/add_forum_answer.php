<?php include("header.php");
$qid=$_GET['qid'];
?>
<main>
        <div class="breadcrumb-area bg-img" data-bg="assets/img/banner/breadcrumb-banner.webp">
            <div class="container">
                <div class="row">
                    <div class="col-12">
                        <div class="breadcrumb-wrap text-center">
                            <nav aria-label="breadcrumb">
                                <h1 class="breadcrumb-title">Add New Forum Answer</h1>
                                
                            </nav>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="login-register-wrapper section-padding">
            <div class="container">
                <div class="member-area-from-wrap">
                    <div class="row">                     
                    <div class="col-lg-3"></div>
                        <div class="col-lg-6">
                            <div class="login-reg-form-wrap signup-form">
                                <form  method="post">
                                    <div class="single-input-item" >
                                        <textarea type="text" rows="5" placeholder="Enter your Answer" name="udetail" required></textarea> 
                                    </div>
                                    <br>
                                    <div class="single-input-item">
                                        <button class="btn" name="btn_register" type="submit">Add Now</button>
                                    </div>
                                </form>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </main>
<?php include("footer.php"); ?>

<?php 
if(isset($_POST['btn_register']))
{

$udetail=$_POST['udetail'];
$uemail=$_SESSION['uemail'];
$uname=$_SESSION['uname'];

$ins_forum="INSERT INTO tbl_forum_answer(question_id,question_detail,user_email,user_name,user_date) VALUES ('$qid','$udetail','$uemail','$uname',NOW())";
$run_forum=mysqli_query($con,$ins_forum);

if($run_forum)
{
    echo "<script>alert('Add Successfully')</script>";
    echo "<script>window.open('forum_detail.php?qid=$qid','_self')</script>";
}
else{
    echo "<script>alert('Add Not Successfully')</script>";
    echo "<script>window.open('forum_detail.php?qid=$qid','_self')</script>";
}    
}
?>