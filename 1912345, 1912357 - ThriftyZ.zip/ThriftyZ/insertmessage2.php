<?php include('function/function.php');
$txtmsg=$_POST['txtmsg'];
$randno=$_POST['randno'];
if($txtmsg == "1")
{
$ins_message="INSERT INTO `tbl_chatbot_message`(random_code,user_message,message_date) VALUES ('$randno','Please Visit This Link to View Orders Status : <b>http://localhost/ThriftyZ/buyer_myorder.php</b>',NOW())";
$run_message=mysqli_query($con,$ins_message);
}
else if($txtmsg == "2")
{
$msgtext="";
$fg_br="select * from tbl_brand";
$run_br=mysqli_query($con,$fg_br);
while($row_br=mysqli_fetch_array($run_br))
{
	$brand_name=$row_br['brand_name'];
	$msgtext.="".$brand_name."<br>";
}
$ins_message="INSERT INTO `tbl_chatbot_message`(random_code,user_message,message_date) VALUES ('$randno','<b>Below are the Brands Available at ThriftyZ :</b><br> $msgtext',NOW())";
$run_message=mysqli_query($con,$ins_message);
}
else if($txtmsg == "3")
{
$msgtext="";
$fg_br="SELECT usale.p_title FROM `tbl_upload_for_sale` usale,tbl_order_detail det where usale.post_id=det.product_id having count(det.detail_id) > 2";
$run_br=mysqli_query($con,$fg_br);
while($row_br=mysqli_fetch_array($run_br))
{
	$p_title=$row_br['p_title'];
	$msgtext.="Best Selling Product is : <b>".$p_title."</b><br>";
}
$ins_message="INSERT INTO `tbl_chatbot_message`(random_code,user_message,message_date) VALUES ('$randno','$msgtext',NOW())";
$run_message=mysqli_query($con,$ins_message);
}
else if($txtmsg == "4")
{
$msgtext="Click on the <b>Search Icon</b> on top right corner of the navigation.";
$ins_message="INSERT INTO `tbl_chatbot_message`(random_code,user_message,message_date) VALUES ('$randno','$msgtext',NOW())";
$run_message=mysqli_query($con,$ins_message);
}
if($txtmsg == "5")
{
$ins_message="INSERT INTO `tbl_chatbot_message`(random_code,user_message,message_date) VALUES ('$randno','Please Visit This Link to Place Contact Querys : <b>http://localhost/ThriftyZ/contact_us.php</b>',NOW())";
$run_message=mysqli_query($con,$ins_message);
}
if($txtmsg == "6")
{
$ins_message="INSERT INTO `tbl_chatbot_message`(random_code,user_message,message_date) VALUES ('$randno','Please Visit This Link to View Forum Portal : <b>http://localhost/ThriftyZ/forum.php</b>',NOW())";
$run_message=mysqli_query($con,$ins_message);

}
if($run_message)
{
	echo "send";
}
else{
	echo "notsend";
}
?>