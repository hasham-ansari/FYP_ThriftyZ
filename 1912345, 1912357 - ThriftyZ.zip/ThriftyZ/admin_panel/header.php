<?php
session_start();
include("../function/function.php");
error_reporting(0);
if(!isset($_SESSION['aemail']))
{
  echo "<script>window.open('admin_login.php','_self')</script>";
}
date_default_timezone_set("Asia/Karachi");
$aid=$_SESSION['aid'];
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no">
    <meta name="description" content="MM Paint Website || Admin Panel  || Order Management">
    <meta name="author" content="MM Paint | Blue Box Business Solution">

  <title> ThriftyZ || Admin Panel   </title>
    <link rel="icon" href="../images/favicons.png" type="image/x-icon" />
    <link rel="shortcut icon" type="image/x-icon" href="../images/favicons.png" />
  <link rel="stylesheet" href="assets/vendor_components/bootstrap/dist/css/bootstrap.css">
  <link href="lib/3/plugins/export/export.css" rel="stylesheet" type="text/css" />
  <link rel="stylesheet" href="css/bootstrap-extend.css">
  <link rel="stylesheet" href="css/master_style.css">
  <link rel="stylesheet" href="css/skins/_all-skins.css">
  <script src="https://kit.fontawesome.com/51238610b6.js" crossorigin="anonymous"></script>
  <script src="jquery-3.6.0.js" integrity="sha256-H+K7U5CnXl1h5ywQfKtSj8PCmoN9aaq30gDh27Xc0jk=" crossorigin="anonymous"></script>
  <script src="jquery.ajaxy.min.js"></script>
  </head>

<body class="hold-transition skin-yellow sidebar-mini">
<div class="wrapper">
  <header class="main-header">
    <a href="index.php" class="logo">
    <b class="logo-mini">
    </b>
      <span class="logo-lg">
    </span>
    </a>
    <nav class="navbar navbar-static-top">
      <a href="#" class="sidebar-toggle" data-toggle="push-menu" role="button">
        <span class="sr-only">Toggle navigation</span>
      </a>

      <div class="navbar-custom-menu">
        <ul class="nav navbar-nav">
      
        </ul>
      </div>
    </nav>
  </header>
  
  <aside class="main-sidebar">
    <section class="sidebar">
      <div class="user-panel">
     <div class="ulogo">
       <a href="index.php">
      </a>
    </div>
        <div class="image">

        </div>
        <div class="info">
          <p>ThriftyZ</p>
      
            <a href="admin_logout.php" class="link" data-toggle="tooltip" title="" data-original-title="Logout"><i class="fa fa-sign-out"></i></a>
        </div>
      </div>
      <ul class="sidebar-menu" data-widget="tree">
    <li class="nav-devider" style="margin-top: -10px"></li>
        <li class="active" style="margin-top: -10px">
          <a href="index.php">
          <i class="fas fa-tachometer-alt"></i> <span>Dashboard</span>
            <span class="pull-right-container">
              <i class="fa fa-angle-right pull-right"></i>
            </span>
          </a>
        </li>
          <li class="treeview">
          <a href="#">
            <i class="fas fa-tachometer-alt"></i>
            <span>Registered Users</span>
            <span class="pull-right-container">
             <i class="fa fa-angle-right pull-right"></i>
            </span>
          </a>
          <ul class="treeview-menu">
            <li><a href="buyer_list.php">Buyer's List</a></li>

            <li><a href="seller_list.php">Seller's List</a></li>
         
          </ul>
        </li>

        <li class="treeview">
          <a href="#">
            <i class="fas fa-tachometer-alt"></i>
            <span>Uploaded Products</span>
            <span class="pull-right-container">
             <i class="fa fa-angle-right pull-right"></i>
            </span>
          </a>
          <ul class="treeview-menu">
            <li><a href="bidding_product_list.php">Auction Products</a></li>

            <li><a href="for_sale_product_list.php">Sale Products</a></li>
         
          </ul>
        </li>
         <li class="treeview">
          <a href="#">
            <i class="fas fa-tachometer-alt"></i>
            <span>Orders</span>
            <span class="pull-right-container">
             <i class="fa fa-angle-right pull-right"></i>
            </span>
          </a>
          <ul class="treeview-menu">
            <li><a href="order_list.php">Order List</a></li>

         
          </ul>
        </li>
        <li class="treeview">
          <a href="#">
            <i class="fas fa-tachometer-alt"></i>
            <span>Auction</span>
            <span class="pull-right-container">
             <i class="fa fa-angle-right pull-right"></i>
            </span>
          </a>
          <ul class="treeview-menu">
            <li><a href="bidding_list.php">Bidding List</a></li>
          </ul>
        </li>

         <li class="treeview">
          <a href="#">
            <i class="fas fa-tachometer-alt"></i>
            <span>Contact Us</span>
            <span class="pull-right-container">
             <i class="fa fa-angle-right pull-right"></i>
            </span>
          </a>
          <ul class="treeview-menu">
            <li><a href="message_list.php">Messages Recieved</a></li>
          </ul>
        </li>
      </ul>
    </section>
  </aside>