<?php include("header.php"); 
if(isset($_SESSION['uemail']) && $_SESSION['utype'] == "Seller")
{

}
else{
	echo "<script>window.open('user_login.php','_self')</script>";
}
?>
<main>
        <div class="breadcrumb-area bg-img" data-bg="assets/img/banner/breadcrumb-banner.webp">
            <div class="container">
                <div class="row">
                    <div class="col-12">
                        <div class="breadcrumb-wrap text-center">
                            <nav aria-label="breadcrumb">
                                <h1 class="breadcrumb-title">My Account</h1>
                            </nav>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="my-account-wrapper section-padding">
            <div class="container custom-container">
                <div class="row">
                    <div class="col-lg-12">
                        <div class="myaccount-page-wrapper">
                            <div class="row">
                                <div class="col-lg-3 col-md-4">
                                    <div class="myaccount-tab-menu nav" role="tablist">
                                        <button class="active" id="dashboard_btn" type="button" data-bs-target="#dashboard" data-bs-toggle="tab" role="tab" aria-controls="dashboard" aria-selected="true">
                                            <i class="fa fa-dashboard"></i>
                                            Dashboard
                                        </button>
                                        <a href="upload_for_sale.php" id="download_btn"  role="tab" aria-controls="download" aria-selected="false">
                                            <i class="fa fa-cloud-download"></i>
                                            Upload for Sale
                                        </a>
                                         <a href="upload_for_bidding.php" id="download_btn"  role="tab" aria-controls="download" aria-selected="false">
                                            <i class="fa fa-cloud-download"></i>
                                            Upload for Bidding
                                        </a>

                                        <a href="seller_myorder.php" id="download_btn"  role="tab" aria-controls="download" aria-selected="false">
                                         <i class="fa fa-cart-arrow-down"></i>
                                           Orders
                                        </a>
                                        <a href="seller_mybidding.php" id="download_btn"  role="tab" aria-controls="download" aria-selected="false">
                                         <i class="fas fa-gavel"></i>
                                        &nbsp;   Bidding
                                        </a>
                                        <a href="my_chat2.php" id="download_btn"  role="tab" aria-controls="download" aria-selected="false">
                                            <i class="far fa-comment"></i>
                                         &nbsp;  Chat
                                        </a>
                                      
                                        <a href="user_logout.php"><i class="fa fa-sign-out"></i> Logout</a>
                                    </div>
                                </div>
                                <div class="col-lg-9 col-md-8">
                                    <div class="tab-content" id="myaccountContent">
                                        <!-- Single Tab Content Start -->
                                        <div class="tab-pane fade show active" id="dashboard" role="tabpanel" aria-labelledby="dashboard_btn">
                                            <div class="myaccount-content">
                                                <h3>Dashboard</h3>
                                                <div class="welcome">
                                                    <p>Hello, <strong><?php echo $_SESSION['uname']; ?></strong> (If Not <strong>You !</strong><a href="user_logout.php" class="logout"> Logout</a>)</p>
                                                </div>
                                                <p class="mb-0">From your account dashboard. you can easily check & view your recent orders, manage your shipping and billing addresses and edit your password and account details.</p>
                                            </div>
                                        </div>
                                    </div>
                                </div> 
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </main>
<?php include("footer.php"); ?>