 <footer class="main-footer">
    <div class="pull-right d-none d-sm-inline-block">
        <ul class="nav nav-primary nav-dotted nav-dot-separated justify-content-center justify-content-md-end">
		 
		</ul>
    </div>

  </footer>
  <aside class="control-sidebar control-sidebar-dark">
    <ul class="nav nav-tabs nav-justified control-sidebar-tabs">
      <li class="nav-item"><a href="#control-sidebar-home-tab" data-toggle="tab"><i class="fa fa-home"></i></a></li>
      <li class="nav-item"><a href="#control-sidebar-settings-tab" data-toggle="tab"><i class="fa fa-cog fa-spin"></i></a></li>
    </ul>
   
  </aside>
  
  <div class="control-sidebar-bg"></div>
  
	</div>
 	<script src="assets/vendor_components/jquery/dist/jquery.js"></script>
	<script src="assets/vendor_components/popper/dist/popper.min.js"></script>
	<script src="assets/vendor_components/bootstrap/dist/js/bootstrap.js"></script>
	<script src="assets/vendor_components/jquery-slimscroll/jquery.slimscroll.js"></script>
	<script src="assets/vendor_components/fastclick/lib/fastclick.js"></script>
	<script src="lib/3/amcharts.js" type="text/javascript"></script>
	<script src="lib/3/gauge.js" type="text/javascript"></script>
	<script src="lib/3/serial.js" type="text/javascript"></script>
	<script src="lib/3/amstock.js" type="text/javascript"></script>
	<script src="lib/3/pie.js" type="text/javascript"></script>
	<script src="lib/3/plugins/animate/animate.min.js" type="text/javascript"></script>
	<script src="lib/3/plugins/export/export.min.js" type="text/javascript"></script>
	<script src="lib/3/themes/patterns.js" type="text/javascript"></script>
	<script src="lib/3/themes/light.js" type="text/javascript"></script>	
	<script src="assets/vendor_components/Web-Ticker-master/jquery.webticker.min.js"></script>
	<script src="assets/vendor_components/echarts-master/dist/echarts-en.min.js"></script>
	<script src="assets/vendor_components/echarts-liquidfill-master/dist/echarts-liquidfill.min.js"></script>
  <script src="assets/vendor_plugins/DataTables-1.10.15/media/js/jquery.dataTables.min.js"></script>
	<script src="js/template.js"></script>
	<script src="js/pages/dashboard.js"></script>
	<script src="js/pages/dashboard-chart.js"></script>
	<script src="js/demo.js"></script>
  <script src="assets/vendor_plugins/DataTables-1.10.15/media/js/jquery.dataTables.min.js"></script>
  <script src="assets/vendor_plugins/DataTables-1.10.15/extensions/Buttons/js/dataTables.buttons.min.js"></script>
  <script src="assets/vendor_plugins/DataTables-1.10.15/extensions/Buttons/js/buttons.flash.min.js"></script>
  <script src="assets/vendor_plugins/DataTables-1.10.15/ex-js/jszip.min.js"></script>
  <script src="assets/vendor_plugins/DataTables-1.10.15/ex-js/pdfmake.min.js"></script>
  <script src="assets/vendor_plugins/DataTables-1.10.15/ex-js/vfs_fonts.js"></script>
  <script src="assets/vendor_plugins/DataTables-1.10.15/extensions/Buttons/js/buttons.html5.min.js"></script>
  <script src="assets/vendor_plugins/DataTables-1.10.15/extensions/Buttons/js/buttons.print.min.js"></script>
  <script src="js/pages/data-table.js"></script>
	     <script src="jquery-3.6.0.min.js"></script>
</body>
</html>