<?php 
include('function/function.php');
$sendid=$_POST['sendid'];
$recid=$_POST['recid'];
error_reporting(0);
$fg_message="SELECT * FROM `tbl_chat_message` WHERE sender_id='$sendid' OR receiver_id='$sendid' order by msg_id asc";
$output="<li class='media d-flex sent' style=''>
		<div class='media-body flex-grow-1' >
<div class='msg-box'>
<div>
</div>
</div>
</div>
</li>
";
$run_message=mysqli_query($con,$fg_message);
while($row_message=mysqli_fetch_array($run_message))
{
	$sender_id=$row_message['sender_id'];
	$receiver_id=$row_message['receiver_id'];
	$msg_text=$row_message['msg_text'];

	if($sender_id == $sendid)
	{

		$output.="<li class='media d-flex sent' style=''>
		<div class='media-body flex-grow-1' >
<div class='msg-box'>
<div>
<p style='padding:5px;margin-top:5px;color:#F1A412;font-weight:bold;text-align:right;'>$msg_text</p>
</div>
</div>
</div>
</li>";

	}
	if($sender_id != $sendid)
	{
     $output.="<li class='media d-flex' style='text-align:left;'>


<div class='media-body flex-grow-1' style='background-color:#F9FAFC;padding:5px;margin-top:5px;color:black;width:250px !important'>
<div class='msg-box'>
<div>
<p>$msg_text</p>

</div>
</div>
</div>
</li>";
	}
}
echo $output;
?>