<?php include("header.php"); 
if(isset($_SESSION['uemail']) && $_SESSION['utype'] == "Buyer"){}
else{
	echo "<script>window.open('user_login.php','_self')</script>";
}
?>
    <main>
        <div class="breadcrumb-area bg-img" data-bg="assets/img/banner/breadcrumb-banner.webp">
            <div class="container">
                <div class="row">
                    <div class="col-12">
                        <div class="breadcrumb-wrap text-center">
                            <nav aria-label="breadcrumb">
                                <h1 class="breadcrumb-title">My Account</h1>
                               
                            </nav>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="my-account-wrapper section-padding">
            <div class="container custom-container">
                <div class="row">
                    <div class="col-lg-12">
                        <div class="myaccount-page-wrapper">
                            <div class="row">
                                <div class="col-lg-3 col-md-4">
                                    <div class="myaccount-tab-menu nav" role="tablist">
                                        <button class="active" id="dashboard_btn" type="button" data-bs-target="#dashboard" data-bs-toggle="tab" role="tab" aria-controls="dashboard" aria-selected="true">
                                            <i class="fa fa-dashboard"></i>
                                            Dashboard
                                        </button>
                                        
                                        <a href="mycart.php" id="download_btn"  role="tab" aria-controls="download" aria-selected="false">
                                            <i class="fa fa-cart-plus"></i>
                                            My Cart
                                        </a>

                                        <a href="buyer_myorder.php" id="download_btn"  role="tab" aria-controls="download" aria-selected="false">
                                            <i class="fa fa-cart-plus"></i>
                                           Orders
                                        </a>

                                        <a href="my_bids.php" id="download_btn"  role="tab" aria-controls="download" aria-selected="false">
                                            <i class="fa fa-cart-plus"></i>
                                           My Bids
                                        </a>

                                        <a href="my_winbids.php" id="download_btn"  role="tab" aria-controls="download" aria-selected="false">
                                            <i class="fa fa-credit-card"></i>
                                           Win Bids
                                        </a>
                                         
                                        <a href="my_chat.php" id="download_btn"  role="tab" aria-controls="download" aria-selected="false">
                                            <i class="far fa-comment"></i>
                                           Chat
                                        </a>
                                        <a href="user_logout.php"><i class="fa fa-sign-out"></i> Logout</a>
                                    </div>
                                </div>
                                <div class="col-lg-9 col-md-8">
                                    <div class="tab-content" id="myaccountContent">
                                        <div class="tab-pane fade show active" id="dashboard" role="tabpanel" aria-labelledby="dashboard_btn">
                                            <div class="myaccount-content">
                                                <h3>Dashboard</h3>
                                                <div class="welcome">
                                                    <p>Hello, <strong><?php echo $_SESSION['uname']; ?></strong> (If Not <strong>You !</strong><a href="user_logout.php" class="logout"> Logout</a>)</p>
                                                </div>
                                                <p class="mb-0">From your account dashboard. you can easily Manage & view your recent orders, manage your shipping, billing and account details.</p>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </main>
<?php include("footer.php"); ?>