<?php
include("header.php");

?>  
<div class="content-wrapper">
  <section class="content-header">
    <h1>
      Auction 
    </h1>
    <ol class="breadcrumb">
      <li class="breadcrumb-item"><a href="#"><i class="fa fa-dashboard"></i> Home</a></li>
      <li class="breadcrumb-item"><a href="#">Auction</a></li>
      <li class="breadcrumb-item active">Bidding List</li>
    </ol>
  </section>

  <section class="content">
    <div class="row">
      <div class="col-12">
        <div class="box box-solid bg-dark">
          <div class="box-body">
				    <div class="table-responsive">
				      <table border="1" style="width:100%">
					      <thead>
						      <tr style="background-color:skyblue;color:black;">
							    <th><center>Id</center></th> 
                  <th><center>Image</center></th>
                  <th><center>Post Title</center></th>
                  <th><center>Bid Start</center></th>
                  <th><center>Bid Amount</center></th>
                  <th><center>Status</center></th>
						    </tr>
					    </thead>
					    <tbody>

<?php 

$feth_user="SELECT * FROM `tbl_bidding` bids,tbl_upload_for_bidding pst where bids.post_id=pst.post_id";
$run_us=mysqli_query($con,$feth_user);
$index=1;
while($row_order=mysqli_fetch_array($run_us))
{
$p_image1=$row_order['p_image1'];
$p_title=$row_order['p_title'];
$bid_amount=$row_order['bid_amount'];
$bid_id=$row_order['bid_id'];
$p_price=$row_order['p_price'];
$win_status=$row_order['win_status'];
echo "
  <tr style='padding:5px'>
  <td style='border:1px solid black'><center>$bid_id</center></td>
  <td style='border:1px solid black'><center><img src='../upload_image/$p_image1' style='width:130px;height:130px'></center></td>
  <td style='border:1px solid black'><center>$p_title</center></td>
  <td style='border:1px solid black'><center>Rs $bid_amount</center></td>
  <td style='border:1px solid black'><center>Rs $p_price</center></td>
  <td style='border:1px solid black'><center>$win_status</center></td>
  </tr>
";
}
?>
      			 	  </tbody>
      			  </table>
      		  </div>              
          </div>
        </div>
      </div>
    </div>
  </section>
</div>
<?php include("footer.php");?>