<?php 
include('function/function.php');
$randno=$_POST['randno'];

error_reporting(0);
$output="<li class='media d-flex sent' style=''>
		<div class='media-body flex-grow-1' >
<div class='msg-box'>
<div>
<p style='background-color:#F9FAFC;padding:5px;margin-top:5px;color:black;'>
Welcome to Thrift Chatbot System<br>
Please enter the below numbers to proceed.<br>
1. Check order status<br>
2. Brands available at ThriftyZ<br>
3. What Product is Best Selling at ThriftyZ<br>
4. Where to Search for Products<br>
5. Contact Query<br>
6. Forum Portal<br>
</p>
</div>
</div>
</div>
</li>
";
$fg_message="SELECT * FROM `tbl_chatbot_message` WHERE random_code='$randno'";

$run_message=mysqli_query($con,$fg_message);
while($row_message=mysqli_fetch_array($run_message))
{
	$user_message=$row_message['user_message'];
$output.="<li class='media d-flex sent' style=''>
		<div class='media-body flex-grow-1' >
<div class='msg-box'>
<div>
<p style='background-color:#F9FAFC;padding:5px;margin-top:5px;color:black;'>$user_message</p>
</div>
</div>
</div>
</li>";
}
echo $output;
?>