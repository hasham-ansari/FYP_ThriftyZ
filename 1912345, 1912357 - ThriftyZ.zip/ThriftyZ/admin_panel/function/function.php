<?php
$con=mysqli_connect("localhost","root","","thriftyz_db");
?>